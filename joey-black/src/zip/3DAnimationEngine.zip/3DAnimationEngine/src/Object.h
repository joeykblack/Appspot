#ifndef OBJECT_H_
#define OBJECT_H_

#include "v3d.h"
#include <vector>
#include <stdlib.h>
#include <iostream>
#include <fstream>
using namespace std;

struct Point {
	float x;
	float y;
	float z;
} ;

struct Edge {
	int a;
	int b;
} ;

struct Surface {
    int * p;
} ;

struct light {
       v3d i;
       v3d dir;
} ;




static bool wirem;
void togleSolid();

class Object
{
public:
	Object(char name[]);
	void load3DS(char name[]);
	void loadOFF(char name[]);
	void draw();
	void draws(int i);
	void translate(float tx, float ty, float tz);
	void move(float x, float y, float z);
	void scale(float sx, float sy, float sz, float fx, float fy, float fz);
	void rotx(float th, float yc, float zc);
	void roty(float th, float xc, float zc);
	void rotz(float th, float xc, float yc);
	void rotab(float th, float xb, float yb, float zb, float xa, float ya, float za);
	void zshx(float m);
	void zshy(float m);
	void xshy(float m);
	void xshz(float m);
	void yshx(float m);
	void yshz(float m);
	char * getName();
	void print();
	void setD(float newd);
	float getD();
private:
	void p3f(float x, float y, float z);
	float findZmax(Surface s);
	char filetype[20];
	char oname[20];
	int np;
	Point * points;
	int ne;
	Edge * edges;
	int ns, ncol;
	Surface * surfaces;
	bool wire;
	vector<light*>* l;
    v3d amb;
    v3d dif;
    v3d spe;
    int n;
    ifstream ins;
};

#endif /*OBJECT_H_*/
