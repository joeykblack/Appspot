#ifdef _WIN32
#define WIN32_EXTRALEAN   
#include <windows.h>
#endif

#include "display3D.h"
#include "Object.h"
#include "Bezier.h"
#include "v3d.h"
#include <GL/glut.h>
#include <GL/gl.h>
#include <GL/glu.h>
#include <algorithm>
#include <string.h>
#include <iostream>
#include <math.h>
#include <fstream>
#include <iomanip>
#include <stdio.h>
#include <time.h>
#include <ctime>
#include <unistd.h>
#include <sys/time.h>
using namespace std;

int sxa = 0; //left
int sya = 800; //up
int sxb = 1000; //right
int syb = 0;  //down

vector<Object*> objects; 
char* objFileNames[25];
vector<visSurf*> visS;
vector<light*> l;
vector<Bezier*> bez;
vector<v3d*>* p;
vector<v3d*> curBezPoints;
vector<Anim*> setup;
vector<Anim*> mainLoop;
int numIter, curIter=0;
Object* curob;
int win2=0;

int mo;
int menuo=2;


//DWORD start, end;//for timing
//DWORD last;
//float start, end;//for timing
timeval last, cur;
float fps;
bool setAnim=false;



void draw3d() {
	glClearColor(1,1,1,1);
	glClear(GL_COLOR_BUFFER_BIT);	
	
	glColor3f(0,0,0);
	
	for (int i=0; i<visS.size(); i++) {
        delete visS.at(i);
    }
	visS.clear();
	for (unsigned int i=0; i<objects.size(); i++) {
		objects[i]->draw();  //3DS will add visible surface to vis
	}
	//draw vis
	sortvis();
	//cout << endl;
	//cout << "Vis Surf zmax: " << endl;
	for (int i=0; i<visS.size(); i++) {
        visS[i]->o->draws(visS[i]->i);
        //cout << visS[i]->zmax << endl;
    }
	
	glutSwapBuffers();
}

void addvis(Object * o, int i, float zmax) {
     visSurf *v = new visSurf;
     v->o = o;
     v->i = i;
     v->zmax = zmax;
     visS.push_back(v);
}

void sortvis() {
     visSurf* temp;
     if (visS.size()==0) return;
     //cout << endl << "sort" << endl;
     //sort(visS.begin(), visS.end());
     for (int i=0; i<visS.size(); i++) {
     for (int j=i+1; j<visS.size(); j++) {
         //cout << "zmaxes: " << visS[i]->zmax << " " << visS[j]->zmax << endl;
         if (visS[i]->zmax > visS[j]->zmax) {
            temp = visS[i];
            visS[i] = visS[j];
            visS[j] = temp;
            //cout << visS[i]->zmax << endl;
         }
     }
     }
}


void creatDisplay() {
	glutInitWindowSize((int)(fabs(sxa)+fabs(sxb)), (int)(fabs(sya)+fabs(syb)));
	glutInitWindowPosition(470,10);
	win2 = glutCreateWindow("Animation");
	glutDisplayFunc(draw3d);
	glutMouseFunc(mouse3d);
	glutIdleFunc(idle);
	
	glViewport(sxa,syb,sxb,sya);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D(sxa,sxb,syb,sya);
    glMatrixMode(GL_MODELVIEW);
	glDisable(GL_DEPTH_TEST);
	
	//curob=new Object("sphere.in");
	//objects.push_back(curob);
	//curob=new Object("p2t5.in");
	//objects.push_back(curob);
	
	addLight(makeLight(-1, -1, -1, 1, 1, 1));
	
	//menue
	//mo = glutCreateMenu(menuFcnObj);
	//if (curob!=NULL) glutAddMenuEntry(curob->getName(), 1);
	//glutAttachMenu(GLUT_RIGHT_BUTTON);
	
	char input[50];
	cout << "Input file: ";
	cin >> input;
	animation(input);
}

void mouse3d(int button, int state, int x, int y) {
	if (state == GLUT_UP )
	{
		if ( button == 3 )
		{
			curob->setD(curob->getD()+10);
		}
		else if( button == 4 )
		{
			curob->setD(curob->getD()-10);
		}
	}
}

void load(char * file) {
    glutSetMenu(mo);
    curob=new Object(file);
	objects.push_back(curob);
	glutAddMenuEntry(curob->getName(), menuo);
	menuo++;
	glutSetWindow(getWindow());
	glutPostRedisplay();
}

Object * getCurO() {
	return curob;
}

int getWindow() {
	return win2;
}

void resize(int xa, int ya, int xb, int yb) {
	glutSetWindow(win2);
	glutReshapeWindow((int)(fabs(xa)+fabs(xb)), (int)(fabs(ya)+fabs(yb)));
	
	
	glViewport(xa,yb,xb,ya);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D(xa,xb,yb,ya);
    glMatrixMode(GL_MODELVIEW);
    
    
    glutPostRedisplay();
}

void clearS() {
    for (int i=0; i<objects.size(); i++) {
        delete objects.at(i);
    }
	objects.clear();
	curob=NULL;
	/*glutSetMenu(mo);
	for (int i=1; i<menuo; i++) {
        glutRemoveMenuItem(1);
    }
    menuo=1;*/
	glutSetWindow(win2);
	glutPostRedisplay();
}

light* makeLight(float dx, float dy, float dz, float ix, float iy, float iz) {
    light* l1 = new light;
    l1->dir.x = dx; l1->dir.y = dy; l1->dir.z = dz;
    l1->i.x = ix; l1->i.y = iy; l1->i.z = iz; 
	return l1;
}

vector<light*>* getLight() {
    return &l;
}

void addLight(light* l1) {
     l.push_back(l1);
}

void redisplayD3D() {
     glutSetWindow(win2);
     glutPostRedisplay();
}


void menuFcnObj(int i) { 
     i--;
     //cout << "i: " << i << endl;
     if (i<objects.size() && i>=0) {
        curob = objects[i];
     }
     else {
          //cout << "out of bounds: " << i << endl;
     }
}

void turnOffLight() {
     for (int i=0; i<l.size(); i++) {
        delete l.at(i);
     }
     l.clear();
}





/*****************
*** Animation ****
*****************/

void idle() {
	gettimeofday(&cur, 0);
    if (cur.tv_sec-last.tv_sec>0 || cur.tv_usec-last.tv_usec>30) {
            //start = GetTickCount();
            update();
            gettimeofday(&last, 0);
            //cout << "Update: " << (last-start) << endl;
            
            //start = GetTickCount();
            draw3d();
            //last = GetTickCount();
            //cout << "Draw: " << (last-start) << endl;
    }
}



void update() {
    for (int i=0; i<curBezPoints.size(); i++) {
        delete curBezPoints.at(i);
    }
    curBezPoints.clear();
    for (int b=0; b<bez.size(); b++) {
        v3d* n = bez.at(b)->next();
        curBezPoints.push_back(n);
    }
    
    if (!setAnim) {
        doActions(setup);
        setAnim = true;
    }
    else {
        doActions(mainLoop);
    }
    
    curIter++;
    if (curIter>=numIter) {
        glutIdleFunc(NULL); //stop
        //reset();
    }
}


void doActions(vector<Anim*> acts) {
    for (int a=0; a<acts.size(); a++) {
        action(acts.at(a));
    }
}

void action(Anim* act) {
    curob = act->o;
    float * params = act->params;
    v3d* b;
    switch (act->transNum) {
        case 1:
            curob->translate(params[0], params[1], params[2]);
            break;
        case 2:
            curob->scale(params[0], params[1], params[2], params[3], params[4], params[5]);
            break;
        case 3:
            curob->rotx(params[0], params[1], params[2]);
            break;
        case 4:
            curob->roty(params[0], params[1], params[2]);
            break;
        case 5:
            curob->rotz(params[0], params[1], params[2]);
            break;
        case 6:
            curob->rotab(params[0], params[1], params[2], params[3], params[4], params[5], params[6]);
            break;
        case 7:
            curob->zshx(params[0]);
            break;
        case 8:
            curob->zshy(params[0]);
            break;
        case 9:
            curob->xshy(params[0]);
            break;
        case 10:
            curob->xshz(params[0]);
            break;
        case 11:
            curob->yshx(params[0]);
            break;
        case 12:
            curob->yshz(params[0]);
            break;
        case 13:
            //cout << "act bez" << endl;
            b = curBezPoints.at((int)params[0]);
            //print(*b);
            curob->move(b->x, b->y, b->z);
            break;
        case 14:
            curob->move(params[0], params[1], params[2]);
            break;
        default:
            return;
    }
}



//load anim
void animation(char name[]) {
	ifstream ins;
	ins.open (name);
	char junk[20];
	char objFile[20];
	int numObj, numBez;
	int curObj, numTrans;
	int numLoops;
	if (ins.is_open()) {
        ins >> junk; //Load:
        ins >> numObj;
        (*objFileNames) = new char(numObj);
        for (int o=0; o<numObj; o++) {
            ins >> objFile;
            objFileNames[o] = objFile;
            curob=new Object(objFile);
	        objects.push_back(curob);
        }
        ins >> junk; //Bez:
        ins >> numBez;
        p = new vector<v3d*>[numBez];
        for (int b=0; b<numBez; b++) {
            int numCtrl;
            ins >> numCtrl;
            int x,y,z;
            for (int c=0; c<numCtrl; c++) {
                ins >> x >> y >> z;    
                p[b].push_back(newv3d(x,y,z));
            }
            int numP;
            ins >> numP;
            bez.push_back(new Bezier(numCtrl, p[b], numP));
        }
        ins >> junk; //Setup:
        for (int o=0; o<numObj; o++) {
            ins >> junk; //Obj
            ins >> curObj;
            ins >> numTrans;
            for (int t=0; t<numTrans; t++) {
                Anim* a = loadAnim(&ins, curObj);
                if (a!=NULL) setup.push_back(a);
                else {cout << "NULL animation." << endl; delete a;}
            }
        }
        ins >> junk; //MainLoop
        ins >> numIter;
        for (int o=0; o<numObj; o++) {
            ins >> junk; //Obj
            ins >> curObj; //should = o
            ins >> numTrans;
            for (int t=0; t<numTrans; t++) {
                Anim* a = loadAnim(&ins, curObj);
                if (a!=NULL) mainLoop.push_back(a);
                else {cout << "NULL animation." << endl; delete a;}
            }
        }
        //EndLoop (end file)
    } //end if open
    ins.close();
}// end animation



int convTransName(char name[]) {
    if (strcmp(name,"translate")==0) {
        return 1;
    }
    else if (strcmp(name,"scale")==0) {
        return 2;
    }
    else if (strcmp(name,"rotx")==0) {
        return 3;
    }
    else if (strcmp(name,"roty")==0) {
        return 4;
    }
    else if (strcmp(name,"rotz")==0) {
        return 5;
    }
    else if (strcmp(name,"rotab")==0) {
        return 6;
    }
    else if (strcmp(name,"zshx")==0) {
        return 7;
    }
    else if (strcmp(name,"zshy")==0) {
        return 8;
    }
    else if (strcmp(name,"xshy")==0) {
        return 9;
    }
    else if (strcmp(name,"xshz")==0) {
        return 10;
    }
    else if (strcmp(name,"yshx")==0) {
        return 11;
    }
    else if (strcmp(name,"yshz")==0) {
        return 12;
    }
    else if (strcmp(name,"bez")==0) {
        return 13;
    }
    else if (strcmp(name,"move")==0) {
        return 14;
    }
    cout << "Bad translation: " << name << endl;
    return -1;
}


Anim* loadAnim(ifstream* ins, int curObj) {
    char tName[20];
    float * params;
    (*ins) >> tName;
    //cout << tName << endl;
    int tNum;
    tNum = convTransName(tName);
    switch (tNum) {
        case 1:
        case 3:
        case 4:
        case 5:
        case 14:
            params = new float[3];
            (*ins) >> params[0] >> params[1] >> params[2];
            break;
        case 2:
            params = new float[6];
            (*ins) >> params[0] >> params[1] >> params[2] >> params[4] >> params[5] >> params[6];
            break;
        case 6:
            params = new float[7];
            (*ins) >> params[0] >> params[1] >> params[2] >> params[4] >> params[5] >> params[6] >> params[7];
            break;
        case 7:
        case 8:
        case 9:
        case 10:
        case 11:
        case 12:
            params = new float[1];
            (*ins) >> params[0];
            break;
        case 13:
            //cout << "load bez" << endl;
            params = new float[1];
            (*ins) >> params[0];
            break;
        default:
            return NULL;
    }// end switch
    Anim* a = new Anim;
    a->o = objects.at(curObj);
    a->params = params;
    a->transNum = tNum;
    return a;
}

void reset() {
    curIter = 0;
    setAnim = false;
    /*clearS();
    for (int o=0; o<sizeof(objFileNames)/sizeof(char[25]); o++) {
            cout << objFileNames[o] << endl;
            curob=new Object(objFileNames[o]);
	        objects.push_back(curob);
    }*/
}






