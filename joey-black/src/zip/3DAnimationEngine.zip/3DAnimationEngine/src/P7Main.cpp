#ifdef _WIN32
#define WIN32_EXTRALEAN    
#include <windows.h>
#endif

#include "display3D.h"
#include "v3d.h"
#include <GL/glut.h>
#include <GL/GL.h>
#include <iostream>
using namespace std;

int main(int argc, char *argv[])
{
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB);
	creatDisplay();
	//start
	glutMainLoop();
}
