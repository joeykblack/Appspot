#ifndef DISPLAY3D_H_
#define DISPLAY3D_H_

#include "Object.h"
#include "v3d.h"
#include <vector>
#include <stdlib.h>
#include <fstream>
using namespace std;

struct visSurf {
       Object * o;
       int i;
       float zmax;
       bool operator < (const visSurf & v2) const {
            return zmax < v2.zmax;
       }
} ;


struct Anim {
    Object* o;
    //char name[20]; //translate, scale...
    int transNum; // 1=translate, 2=... (see convTransName)
    float * params;
} ;


void creatDisplay();
void draw3d();
void idle();
void mouse3d(int button, int state, int x, int y);
Object * getCurO();
int getWindow();
void resize(int xa, int ya, int xb, int yb);
void load(char * file);
void clearS();
void addvis(Object * o, int i, float zmax);
void sortvis();
light* makeLight(float dx, float dy, float dz, float ix, float iy, float iz);
vector<light*>* getLight();
void addLight(light* l1);
void redisplayD3D();
void menuFcnObj(int i);
void turnOffLight();

void animation(char name[]);
int convTransName(char name[]);
Anim* loadAnim(ifstream* ins, int curObj);
void update();
void doActions(vector<Anim*> acts);
void action(Anim* act);
void reset();


#endif /*DISPLAY3D_H_*/
