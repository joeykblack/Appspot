#ifdef _WIN32
#define WIN32_EXTRALEAN   
#include <windows.h>
#endif

#include "Object.h"
#include "display3D.h"
#include "v3d.h"
#include <iostream>
#include <fstream>
#include <string.h>
#include <iomanip>
#include <math.h>
#include <GL/glut.h>
using namespace std;

static float d=5000;
 
//creates a new object given a file name
Object::Object(char name[]) {
	ins.open (name);
	if (ins.is_open()) {
        ins >> filetype;
        if (strcmp("3DS", filetype)==0) load3DS(name);
        else if (strcmp("3DW", filetype)==0) load3DS(name);
        else if (strcmp("2DW", filetype)==0) load3DS(name);
        else if (strcmp("OFF", filetype)==0) loadOFF(name);
        else {
            cout << "Unknown file type: " << filetype << " in file: " << name << endl;
        }
	}
	else {
         cout << "Fail to open: " << name << endl;
    }
	
	ins.close();
	//print();
}


void Object::load3DS(char name[]) {
		if (strcmp("3DS", filetype)==0) wire = false;
		else wire = true;
		ins >> oname;
		ins >> np;
		points = new Point[np];
		for (int i=0; i<np; i++) {
			ins >> points[i].x;
			ins >> points[i].y;
			if ((strcmp("3DW", filetype)==0) || (strcmp("3DS", filetype)==0)) {
				ins >> points[i].z;
			}
			else {
				points[i].z = 0;
			}
		}
		ins >> ne;
		edges = new Edge[ne];
		for (int i=0; i<ne; i++) {
			ins >> edges[i].a;
			ins >> edges[i].b;
			if (strcmp("3DS", filetype)==0) {  //3DS points are labeled 1-n but need to be 0-(n-1)
               edges[i].a--;
               edges[i].b--;
            }
		}
		if (strcmp("3DS", filetype)==0) {
    		ins >> ns;
    		ins >> ncol;
    		//cout << "load ncol: " << ncol << endl;
    		surfaces = new Surface[ns];
    		for (int i=0; i<ns; i++) {
                surfaces[i].p = new int[ncol];
                for (int j=0; j<ncol; j++) {
                    ins >> surfaces[i].p[j];
                    surfaces[i].p[j]--; //3DS points are labeled 1-n but need to be 0-(n-1)
                }
            }
            //load lighting
            ins >> amb.x >> amb.y >> amb.z;
            ins >> dif.x >> dif.y >> dif.z;
            ins >> spe.x >> spe.y >> spe.z;
            ins >> n;
            /*cout << amb.x << " " << amb.y << " " << amb.z << endl;
            cout << dif.x << " " << dif.y << " " << dif.z << endl;
            cout << spe.x << " " << spe.y << " " << spe.z << endl;
            cout << n << endl;*/
        }
}


void Object::loadOFF(char name[]) {
        //cout << "loading off" << endl;
        // Declare temporary variables to read data into.
		// If the read goes well, we'll copy these into
		// our class variables, overwriting what used to 
		// be there. If it doesn't, we won't have messed up
		// our previous data structures.
		int tempNumPoints   = 0;	// Number of x,y,z coordinate triples
		int tempNumFaces    = 0;	// Number of polygon sets
		int tempNumEdges    = 0;	// Unused, except for reading.
		double** tempPoints = NULL;	// An array of x,y,z coordinates.
		int** tempFaces = NULL;		// An array of arrays of point
						// pointers. Each entry in this
						// is an array of integers. Each
						// integer in that array is the
						// index of the x, y, and z
						// coordinates in the corresponding
						// arrays.
		int*  tempFaceSizes = NULL;	// An array of polygon point counts.
						// Each of the arrays in the tempFaces
						// array may be of different lengths.
						// This array corresponds to that
						// array, and gives their lengths.
		int i;				// Generic loop variable.
		bool goodLoad = true;		// Set to false if the file appears
						// not to be a valid OFF file.
		char tempBuf[128];		// A buffer for reading strings
						// from the file.

		// Grab the first string. If it's "OFF", we think this
		// is an OFF file and continue. Otherwise we give up.
		if (strcmp(filetype, "OFF") != 0) {
			goodLoad = false;
		}

		// Read the sizes for our two arrays, and the third
		// int on the line. If the important two are zero
		// sized, this is a messed up OFF file. Otherwise,
		// we setup our temporary arrays.
		if (goodLoad) {
			ins >> tempNumPoints >> tempNumFaces >> tempNumEdges;
			if (tempNumPoints < 1 ||
				tempNumFaces < 1) {
				// If either of these were negative, we make
				// sure that both are set to zero. This is
				// important for later deleting our temporary
				// storage.
				goodLoad      = false;
				tempNumPoints = 0;
				tempNumFaces  = 0;
			} else {
				tempPoints = new double*[tempNumPoints];
				tempFaces = new int*[tempNumFaces];
				tempFaceSizes = new int[tempNumFaces];
			}
		}

		if (goodLoad) {
		    // Load all of the points.
		    for (i = 0; i < tempNumPoints; i++) {
				tempPoints[i] = new double[3];
			    ins >> tempPoints[i][0] >> tempPoints[i][1] >> tempPoints[i][2];
			}

			// Load all of the faces.
			for (i = 0; i < tempNumFaces; i++) {
				// This tells us how many points make up
				// this face.
				ins >> tempFaceSizes[i];
				// So we declare a new array of that size
				tempFaces[i] = new int[tempFaceSizes[i]];
				// And load its elements with the vertex indices.
				for (int j = 0; j < tempFaceSizes[i]; j++) {
					ins >> tempFaces[i][j];
				}
				// Clear out any face color data by reading up to
				// the newline. 128 is probably considerably more
				// space than necessary, but better safe than
				// sorry.
				ins.getline(tempBuf, 128);
			}
		}

		// Here is where we copy the data from the temp
		// structures into our permanent structures. We
		// probably will do some more processing on the
		// data at the same time. This code you must fill
		// in on your own.
		if (goodLoad) {
            strcpy(oname, name);
            np = tempNumPoints;
            
            //points
            points = new Point[np];
            for (int p=0; p<np; p++) {
                points[p].x = tempPoints[p][0];
                points[p].y = tempPoints[p][1];
                points[p].z = tempPoints[p][2];
            }
            
            //edges
            ne = tempNumEdges;
    		edges = NULL;//new Edge[ne];
    		
    		//surfaces
    		ns = tempNumFaces;
    		ncol = 0;//changes for each surface
    		surfaces = new Surface[ns];
    		for (int i=0; i<ns; i++) {
                ncol = tempFaceSizes[i];
                surfaces[i].p = new int[ncol];
                for (int j=0; j<ncol; j++) {
                    surfaces[i].p[j] = tempFaces[i][j];
                }
            }
    		amb = makev3d(.2,.2,.2);
    		dif = makev3d(.5,.5,.5);
    		spe = makev3d(.5,.5,.5);
    		n = 20;
    		
            //cout << oname << " loaded." << endl;
		}

		// Now that we're done, we have to make sure we
		// free our dynamic memory.
		for (i = 0; i < tempNumPoints; i++) {
			delete []tempPoints[i];
		}
		delete []tempPoints;

		for (i = 0; i < tempNumFaces; i++) {
			delete tempFaces[i];
		}
		delete []tempFaces;
		delete []tempFaceSizes;

		// Clean up our ifstream. The MFC framework will
		// take care of the CArchive.
		ins.close();

		// If something went wrong, now we'll let the framework know.
		// Note that we've cleaned up after ourselves first. Code
		// after this would not be executed if the load was bad,
		// because the exception will move up to the calling
		// function. (CDocument::OnFileOpen()). This error handling
                // is still not very good as exceptions in the code above
                // may have skipped our clean-up code. A real program would have
                // to do better.
		if (!goodLoad) {
			cout << "Not OFF?" << endl;
		}
}// end load OFF


void Object::draw() {
    if ((strcmp("3DS", filetype)==0) || (strcmp("OFF", filetype)==0)) {
        for (int i=0; i<ns; i++) {
            v3d v1 = makev3d(points[surfaces[i].p[0]].x, points[surfaces[i].p[0]].y, points[surfaces[i].p[0]].z,
                points[surfaces[i].p[1]].x, points[surfaces[i].p[1]].y, points[surfaces[i].p[1]].z);
            v3d v2 = makev3d(points[surfaces[i].p[0]].x, points[surfaces[i].p[0]].y, points[surfaces[i].p[0]].z,
                points[surfaces[i].p[2]].x, points[surfaces[i].p[2]].y, points[surfaces[i].p[2]].z);
            v3d n = cros(v1, v2);
            v3d s = makev3d(points[surfaces[i].p[0]].x, points[surfaces[i].p[0]].y, points[surfaces[i].p[0]].z,  0,0,d);
            if (vis(n, s)) {
               addvis(this, i, findZmax(surfaces[i]));
            }
        }
    }
    else { 
    	glBegin(GL_LINES);
    		for (int e=0; e<ne; e++) {
                p3f(points[edges[e].a].x, points[edges[e].a].y, points[edges[e].a].z);
    			p3f(points[edges[e].b].x, points[edges[e].b].y, points[edges[e].b].z);
    		}
    	glEnd();
    }
}

//project 3d point
void Object::p3f(float x, float y, float z) {
	float zd = 1 - (z/d);
	glVertex2f(x/zd, y/zd);
}


void Object::draws(int i) {
     float r=0,g=0,b=0;
     v3d v1 = makev3d(points[surfaces[i].p[0]].x, points[surfaces[i].p[0]].y, points[surfaces[i].p[0]].z,
                points[surfaces[i].p[1]].x, points[surfaces[i].p[1]].y, points[surfaces[i].p[1]].z);
     v3d v2 = makev3d(points[surfaces[i].p[0]].x, points[surfaces[i].p[0]].y, points[surfaces[i].p[0]].z,
                points[surfaces[i].p[2]].x, points[surfaces[i].p[2]].y, points[surfaces[i].p[2]].z);
     v3d Nu = normalize(cros(v1, v2));
     v3d Lu;
     v3d Su = makev3d(points[surfaces[i].p[0]].x, points[surfaces[i].p[0]].y, points[surfaces[i].p[0]].z,  0,0,d);
     v3d Ru;
     l = getLight();
     //cout << endl;
     //cout << (*l).size() << endl;
     float dotNL, dotSR;
     for (int li=0; li<(*l).size(); li++) {
         Lu = normalize(scalMult(-1, (*l)[li]->dir));
         Ru = calcRu(Nu, Lu);
         //cout << Ru.x << " " << Ru.y << " " << Ru.z << endl;
         dotNL = dot(Nu,Lu);
         if (dotNL<0) dotNL=0;
         dotSR = dot(Su,Ru);
         if (dotSR<0) dotSR=0;
         r += (*l)[li]->i.x *  (  amb.x + (dif.x*dotNL) + (spe.x*pow(dotSR,n))  )  ;
         g += (*l)[li]->i.y *  (  amb.y + (dif.y*dotNL) + (spe.y*pow(dotSR,n))  )  ;
         b += (*l)[li]->i.z *  (  amb.z + (dif.z*dotNL) + (spe.z*pow(dotSR,n))  )  ;
         //cout << "amb: " << amb.x << " " << amb.y << " " << amb.z <<  endl;
         //cout << "dif: " << dif.x << " " << dif.y << " " << dif.z <<  endl;
         //cout << "spe: " << spe.x << " " << spe.y << " " << spe.z <<  endl;
         //cout << " " << r << " " << g << " " << b << " " << dotNL << " " << dotSR << endl;
     }
     if (r>1) r=1;
     if (g>1) g=1;
     if (b>1) b=1;
     //r=g=b=0;
     glColor3f(r, g, b);
     //cout << endl;
     //cout << "points " << i << endl;
     if (wire || wirem) glBegin(GL_LINE_LOOP);
     else glBegin(GL_POLYGON);
         for (int c=0; c<ncol; c++) {
             //cout << "p[c]: " << surfaces[i].p[c] << endl;
             if (surfaces[i].p[c]>=0) {
                   p3f(points[surfaces[i].p[c]].x, points[surfaces[i].p[c]].y, points[surfaces[i].p[c]].z); 
             }
         }
    glEnd();
} 


float Object::findZmax(Surface s) {
     float zmax = points[s.p[0]].z;
     //cout << endl << "Find zmax: " << endl;
     //cout << "ncol: " << ncol << endl;
     
     //cout << zmax << endl;
     for (int i=1; i<ncol; i++) {
         if (s.p[i]<0) continue;
         //cout << points[s.p[i]].z << endl;
         if (points[s.p[i]].z > zmax) zmax = points[s.p[i]].z;
     }
     //cout << "result: " << zmax << endl;
     return zmax;
}



char * Object::getName() {
	return oname;
}

void Object::print() {
	cout << endl << oname << endl;
	cout << "Num points: " << np << endl;
	for (int i=0; i<np; i++) {
		cout << points[i].x << " " << points[i].y << " " << points[i].z << endl;
	}
	cout << "Num edges: " << ne << endl;
	for (int i=0; i<ne; i++) {
		cout << edges[i].a << " " << edges[i].b << endl;
	}
	cout << endl;
}

void Object::setD(float newd) {
	d = newd;
	glutSetWindow(getWindow());
	glutPostRedisplay();
}

float Object::getD() {
	return d;
}



void Object::translate(float tx, float ty, float tz) {
	for (int i=0; i<np; i++) {
		points[i].x += tx;
		points[i].y += ty;
		points[i].z += tz;
	}
	glutSetWindow(getWindow());
	glutPostRedisplay();
}


void Object::move(float x, float y, float z) {
    translate(-1*points[0].x, -1*points[0].y, -1*points[0].z);
    translate(x,y,z);
}


void Object::scale(float sx, float sy, float sz, float fx, float fy, float fz) {
	translate(-fx, -fy, -fz);
	for (int i=0; i<np; i++) {
		points[i].x *= sx;
		points[i].y *= sy;
		points[i].z *= sz;
	}
	translate(fx, fy, fz);
}

void Object::rotx(float th, float yc, float zc) {
	float s = sin((th*M_PI)/180);
	float c = cos((th*M_PI)/180);
	float y,z;
	translate(0, -yc, -zc);
	for (int i=0; i<np; i++) {
		y = points[i].y;
		z = points[i].z;
		points[i].y = (y*c) - (z*s);
		points[i].z = (y*s) + (z*c);
	}
	translate(0, yc, zc);
}

void Object::roty(float th, float xc, float zc){
	float s = sin((th*M_PI)/180);
	float c = cos((th*M_PI)/180);
	float x,z;
	translate(-xc, 0, -zc);
	for (int i=0; i<np; i++) {
		x = points[i].x;
		z = points[i].z;
		points[i].x = (z*s) + (x*c);
		points[i].z = (z*c) - (x*s);
	}
	translate(xc, 0, zc);
}

void Object::rotz(float th, float xc, float yc){
	float s = sin((th*M_PI)/180);
	float c = cos((th*M_PI)/180);
	float x,y;
	translate(-xc, -yc, 0);
	for (int i=0; i<np; i++) {
		x = points[i].x;
		y = points[i].y;
		points[i].x = (x*c) - (y*s);
		points[i].y = (x*s) + (y*c);
	}
	translate(xc, yc, 0);
}


void Object::rotab(float th, float xb, float yb, float zb, float xa, float ya, float za) {
	translate(-xb, -yb, -zb);
	float th1;
	if ((xa-xb)==0) th1=-90;
	else th1=-atan( ((ya-yb)/(xa-xb)) ) *180/M_PI;
	float s = sin((th1*M_PI)/180);
	float c = cos((th1*M_PI)/180);
	float xa2 = (xa*c) - (ya*s);
	float xb2 = (xb*c) - (yb*s);
	float th2;
	if ((za-zb)==0) th2=-90; 
	else th2=-atan( ((xa2-xb2)/(za-zb)) ) *180/M_PI;
	//cout << "rotab" << endl;
	//cout << "th1: " << th1 << endl;
	//cout << "th2: " << th2 << endl;
	rotz(th1,0,0);
	roty(th2,0,0);
	rotz(th,0,0);
	roty(-th2,0,0);
	rotz(-th1,0,0);
	translate(xb, yb, zb);
}


void Object::zshx(float m) {
	float x;
	for (int i=0; i<np; i++) {
		x = points[i].x;
		points[i].x = x + (points[i].y/m);
	}
	glutSetWindow(getWindow());
	glutPostRedisplay();
}


void Object::zshy(float m){
	float y;
	for (int i=0; i<np; i++) {
		y = points[i].y;
		points[i].y = y + (points[i].x/m);
	}
	glutSetWindow(getWindow());
	glutPostRedisplay();
}

void Object::xshy(float m){
	float y;
	for (int i=0; i<np; i++) {
		y = points[i].y;
		points[i].y = y + (points[i].z/m);
	}
	glutSetWindow(getWindow());
	glutPostRedisplay();
}

void Object::xshz(float m){
	float z;
	for (int i=0; i<np; i++) {
		z = points[i].z;
		points[i].z = z + (points[i].y/m);
	}
	glutSetWindow(getWindow());
	glutPostRedisplay();
}

void Object::yshx(float m){
	float x;
	for (int i=0; i<np; i++) {
		x = points[i].x;
		points[i].x = x + (points[i].z/m);
	}
	glutSetWindow(getWindow());
	glutPostRedisplay();
}


void Object::yshz(float m){
	float z;
	for (int i=0; i<np; i++) {
		z = points[i].z;
		points[i].z = z + (points[i].x/m);
	}
	glutSetWindow(getWindow());
	glutPostRedisplay();
}

void togleSolid() {
     if (wirem) wirem=false;
     else wirem=true;
     //cout << wirem << endl;
     glutSetWindow(getWindow());
	 glutPostRedisplay();
}





