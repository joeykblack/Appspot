#include "test.h"
#include "v3d.h"
#include "Sphere.h"
#include <iostream>
using namespace std;

void run() {
    /*Sphere* s1 = new Sphere("s1", 10, 20, 20, 20, 0,0,0,0,0,0,0,0,0,1);
    //Sphere* s2 = new Sphere("s1", 10, 50, 50, 500, 0,0,0,0,0,0,0,0,0,1);
    
    bool t;
    t = s1->arbIntersects(makev3d(30,30,30), makev3d(1,1,1));
    cout << t << endl;
    
    system("PAUSE");*/
}
