#ifdef _WIN32
#define WIN32_EXTRALEAN   
#include <windows.h>
#endif

#include "dispRay3D.h"
#include "Sphere.h"
#include "v3d.h"
#include <GL/glut.h>
#include <GL/GL.h>
#include <GL/glu.h>
#include <algorithm>
#include <string.h>
#include <iostream>
#include <math.h>
#include <vector>
#include <fstream>
#include <time.h>
using namespace std;



vector<Sphere*> s;
vector<light*> l;

int win3D;
int d;
v3d points[WIDTH*2][HEIGHT*2];

bool updated = false;

void creatDisplay() {
    glutInitWindowSize(WIDTH, HEIGHT);
	glutInitWindowPosition(20,10);
	win3D = glutCreateWindow("Ray");
	glutDisplayFunc(draw3d);
	//glutMouseFunc(mouse3d);
	
	glViewport(0,0,WIDTH-1,HEIGHT-1);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D(0,WIDTH-1,0,HEIGHT-1);
    glMatrixMode(GL_MODELVIEW);
	glDisable(GL_DEPTH_TEST);
	
	
	d=5000;
	
	//load spheres
	cout << "File: ";
	char file[20] = "p6t1.txt";
	cin >> file;
	
	ifstream ins;
    ins.open (file);
    int nums;
    if (ins.is_open()) {
          cout << "Opening " << file << endl << endl;
          ins >> nums;
          cout << "Spheres: " << endl << endl;
          for (int i=0; i<nums; i++) {
              char name[20];
              ins >> name;
              cout << name << endl;
              float t[16];
              for (int i=0; i<13; i++) ins >> t[i];
              int n;
              ins >> n;
              ins >> t[13];
              ins >> t[14];
              ins >> t[15];
              cout << t[0] << " " << t[1] << " " << t[2] << " " << t[3] << endl;
              cout << t[4] << " " << t[5] << " " << t[5] << " " << t[5] << " " << t[8] << " ";
              cout << t[9] << " " << t[10] << " " << t[11] << " " << t[12] << " " << n << endl;
              cout << t[13] << " " << t[14] << " " << t[15] << endl << endl;
              s.push_back(new Sphere(name, t[0], t[1], t[2], t[3], t[4], t[5], 
                            t[6], t[7], t[8], t[9], t[10], t[11], t[12], n, 
                            t[13], t[14], t[15]));
          }
          cout << "Light: " << endl << endl;
          int numL;
	      ins >> numL;
	      v3d i, d;
          for (int x=0; x<numL; x++) {
               ins >> i.x >> i.y >> i.z;
               ins >> d.x >> d.y >> d.z;
               cout << "Light" << x << ":" << endl;
               cout << "Intensity: " << i.x << " " << i.y << " " << i.z << endl;
               cout << "Direction: <"<< d.x << " " << d.y << " " << d.z << ">" << endl << endl;
               l.push_back(makeLight(i,d));
	      }
    }
    else {
        cout << "Failed to open." << endl;
    }
    

     //sort by distance from 0,0,d     
     Sphere* temp;
     for (int i=0; i<s.size(); i++) {
     for (int j=i+1; j<s.size(); j++) {
         if (s[i]->getDist() > s[j]->getDist()) {
            temp = s[i];
            s[i] = s[j];
            s[j] = temp;
         }
     }
     }
     
     //light
     //l.push_back(makeLight(makev3d(1,1,1), makev3d(-1,-1,-1)));
     //l.push_back(makeLight(makev3d(.5,.5,.5), makev3d(1,1,-1)));
     update();
     updated = false;
}


void draw3d() {
    //time_t start,end;
    //time (&start);
    
    glClearColor(BACKr,BACKg,BACKb,1);
	glClear(GL_COLOR_BUFFER_BIT);	
	
	glColor3f(BACKr,BACKg,BACKb);
	
	if (!updated) update();
	
	v3d ave;
	glBegin(GL_POINTS);
	   for (int j=1; j<HEIGHT-1; j++) {
       for (int i=1; i<WIDTH-1; i++) {
            ave.x=0; ave.y=0; ave.z=0;
            for (int y=2*j-1; y<=2*j+1; y++) {
            for (int x=2*i-1; x<=2*i+1; x++) {
                ave.x += points[x][y].x;
                ave.y += points[x][y].y;
                ave.z += points[x][y].z;
            }
            }
            ave.x /= 9;
            ave.y /= 9;
            ave.z /= 9;
            glColor3f(ave.x, ave.y, ave.z);
            glVertex2i(i, j);
       }
       }
	glEnd();
	
    /*
    glBegin(GL_POINTS);
	   for (int j=0; j<HEIGHT; j++) {
       for (int i=0; i<WIDTH; i++) {
            //clamp(&points[i][j]);
            //cout << ((points[i][j].z>0) ? "i" : "0");
            glColor3f(points[i][j].x, points[i][j].y, points[i][j].z);
            glVertex2i(i, j);
       }
       //cout << endl;
       }
	glEnd();
	*/
	
	glutSwapBuffers();
	
	//time (&end);
    //double dif = difftime (end,start);
    //printf ("Time: %.2lf\n", dif );
}


int getD() {
    return d;
}

void clamp(v3d * v) {
    v->x = (v->x > 1)? 1 : v->x;
    v->y = (v->y > 1)? 1 : v->y;
    v->z = (v->z > 1)? 1 : v->z;
    v->x = (v->x < 0)? 0 : v->x;
    v->y = (v->y < 0)? 0 : v->y;
    v->z = (v->z < 0)? 0 : v->z;
}



light* makeLight(v3d i, v3d dir) {
    light* l = new light();
    l->dir.x=dir.x;
    l->dir.y=dir.y;
    l->dir.z=dir.z;
    l->i.x=i.x;
    l->i.y=i.y;
    l->i.z=i.z;
    return l;
}


vector<light*>* getLight() {
    return &l;
}


bool arbInt(v3d orig, v3d v) {
    for (int o=0; o<s.size(); o++) {
            if (s[o]->arbIntersects(orig, v)) {  
                return true;
            }
    }
    
    return false;
}



v3d colArbRay(v3d orig, v3d v) {
    v3d c;
    c = makev3d(BACKr,BACKg,BACKb);
    vector<Sphere*> hit;
    Sphere* sphere;
    float minDist, curDist;
    
    for (int o=0; o<s.size(); o++) {
            if (s[o]->calcArbIntersects(orig, v)) {  
                hit.push_back(s[o]);
            }
    }
     
    if (hit.size()>0) {
        minDist = hit[0]->getArbDist(orig);
        sphere = hit[0];
        for (int o=1; o<hit.size(); o++) {
            curDist = hit[o]->getArbDist(orig);
            if (curDist<minDist) {
                minDist = curDist;
                sphere = hit[o];
            }
        }
        c = sphere->colorP(orig);
    }
    
    hit.clear();
    return c;
}

void update() {
    v3d v;
	for (int j=0; j<HEIGHT*2; j++) {
    for (int i=0; i<WIDTH*2; i++) {
        v = makev3d(0,0,d, i,j,0);
        points[i][j] = makev3d(BACKr,BACKg,BACKb);
        //cout << endl << i << ", " << j << endl;
        for (int o=0; o<s.size(); o++) {
            if (s[o]->intersects(v)) {  //if true, the intersection point will be stored in the sphere
                points[i][j] = s[o]->colorP(makev3d(0,0,d));
                clamp(&points[i][j]);
                //cout << i << ", " << j << " intersection." << endl;
                break;  //objects are sorted so no need to check further
            }
        }
    }
    }
    updated = true;
}










