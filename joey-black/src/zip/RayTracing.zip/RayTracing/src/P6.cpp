#ifdef _WIN32
#define WIN32_EXTRALEAN     // Only include the basics
#include <windows.h>
#endif

#include "test.h"

#include "Sphere.h"
#include "dispRay3D.h"
#include <GL/glut.h>
#include <GL/GL.h>
#include <iostream>
#include <vector>
#include <fstream>
using namespace std;

// Initialize GLUT and start main loop
int main(int argc, char** argv) {
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB);
	
	creatDisplay();
	
	//start
	glutMainLoop();
	//run();
}






