#ifndef DISPRAY3D_H_
#define DISPRAY3D_H_

#include "v3d.h"
#include "Sphere.h"
#include <vector>
#include <stdlib.h>
using namespace std;

#define WIDTH 1024
#define HEIGHT 1024
#define BACKr 0
#define BACKg 0
#define BACKb 0

 
struct light {
       v3d i;
       v3d dir;
} ;


void creatDisplay();
void draw3d();
void menuFcnObj(int i);
void resize(int xa, int ya, int xb, int yb);
void load(char * file);
int getWindowDisp();
void update();

light* makeLight(v3d i, v3d dir);
vector<light*>* getLight();
void addLight(light* l1);
void turnOffLight();
int getD();
void clamp(v3d * v);

bool arbInt(v3d orig, v3d v);
v3d colArbRay(v3d orig, v3d v);






#endif /*DISPRAY3D_H_*/
