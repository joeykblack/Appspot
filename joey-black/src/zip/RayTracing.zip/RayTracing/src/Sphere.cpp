#ifdef _WIN32
#define WIN32_EXTRALEAN   
#include <windows.h>
#endif

#include "Sphere.h"
#include "dispRay3D.h"
#include <iostream>
#include <fstream>
#include <string.h>
#include <iomanip>
#include <math.h>
#include <GL/glut.h>
using namespace std;


Sphere::Sphere(char * name, 
               float r, float x, float y, float z, 
               float ambr, float ambg, float ambb, 
               float difr, float difg, float difb, 
               float sper, float speg, float speb, int n,
               float cSta, float cRefl, float cRefr):
               name(name), r(r*2), x(x*2), y(y*2), z(z*2), 
               ambr(ambr), ambg(ambg), ambb(ambb),
               difr(difr), difg(difg), difb(difb),
               sper(sper), speg(speg), speb(speb), n(n),
               cSta(cSta), cRefl(cRefl), cRefr(cRefr)
{
    dist = mag(makev3d(0,0,getD(), x,y,z));
}

float Sphere::getr() {
    return r;
}

float Sphere::getDist() {
    return dist;
}

char* Sphere::getName() {
    return name;
}

//ray from viewer
bool Sphere::intersects(v3d v) {
    v3d u = normalize(v);
    v3d dp = makev3d(0,0,getD(), x,y,z);
    float uDotdp = dot(u, dp);
    float a = mag(difv3d(dp, scalMult(uDotdp, u)));
    float discr = (r*r) - (a*a); 
    
    
    if (discr<0) {
        /*cout << " does not intersect: " << discr << endl;
        cout << " u: ";
        print(u);
        cout << " dp: ";
        print(dp);
        cout << " uDotdp: " << uDotdp << "  a: " << a << endl;*/
        return false;
    }
    
    float t1 = uDotdp + sqrt(discr);
    float t2 = uDotdp - sqrt(discr);
    float t = (t1 < t2)? t1 : t2;
    
    xi = t * u.x;
    yi = t * u.y;
    zi = getD() + t * u.z;
    
    //cout << " does intersect at: " << xi << ", " << yi << ", " << zi << endl;
    
    return true;
}

//for shadow check
bool Sphere::arbIntersects(v3d orig, v3d v) {
    if (cur) return false; //does not intersect self
    v3d u = normalize(v);
    v3d dp = difv3d(makev3d(x,y,z), orig);
    float uDotdp = dot(u, dp);
    if (uDotdp<0) return false;
    float a = mag(difv3d(dp, scalMult(uDotdp, u)));
    float discr = (r*r) - (a*a); 
    
    /*cout << "orig: "; print(orig);
    cout << "u: "; print(u);
    cout << "dp: "; print(dp);
    cout << "a: " << a << endl;
    cout << "uDotdp: " << uDotdp << endl;
    cout << pow(dot(u,dp),2) << " - " << pow(mag(dp),2) << " + " << pow(r, 2) << endl;
    */
    if (discr<0) {
        return false;
    }
    
    return true;
}


bool Sphere::calcArbIntersects(v3d orig, v3d v) {
    if (cur) return false; //does not intersect self
    v3d u = normalize(v);
    v3d dp = difv3d(makev3d(x,y,z), orig);
    float uDotdp = dot(u, dp);
    if (uDotdp<0) return false;
    float a = mag(difv3d(dp, scalMult(uDotdp, u)));
    float discr = (r*r) - (a*a); 
    
    /*cout << "orig: "; print(orig);
    cout << "u: "; print(u);
    cout << "dp: "; print(dp);
    cout << "a: " << a << endl;
    cout << "uDotdp: " << uDotdp << endl;
    cout << pow(dot(u,dp),2) << " - " << pow(mag(dp),2) << " + " << pow(r, 2) << endl;
    */
    if (discr<0) {
        return false;
    }
    
    float t1 = uDotdp + sqrt(discr);
    float t2 = uDotdp - sqrt(discr);
    float t = (t1 < t2)? t1 : t2;
    
    xi = orig.x + (t * u.x);
    yi = orig.y + (t * u.y);
    zi = orig.z + (t * u.z);
    
    return true;
}

float Sphere::getArbDist(v3d a) {
    return mag(difv3d(makev3d(xi,yi,zi), a));
}

bool Sphere::intInter(v3d orig, v3d v) {
    v3d u = normalize(v);
    v3d dp = difv3d(makev3d(x,y,z), orig);
    float uDotdp = dot(u, dp);
    //if (uDotdp<0) return false;
    float a = mag(difv3d(dp, scalMult(uDotdp, u)));
    float discr = (r*r) - (a*a); 
    
    /*cout << "orig: "; print(orig);
    cout << "u: "; print(u);
    cout << "dp: "; print(dp);
    cout << "a: " << a << endl;
    cout << "uDotdp: " << uDotdp << endl;
    cout << pow(dot(u,dp),2) << " - " << pow(mag(dp),2) << " + " << pow(r, 2) << endl;
    */
    if (discr<0) {
        return false;
    }
    
    float t1 = uDotdp + sqrt(discr);
    //float t2 = uDotdp - sqrt(discr);
    //float t = (t1 < t2)? t1 : t2;
    
    xi = orig.x + (t1 * u.x);
    yi = orig.y + (t1 * u.y);
    zi = orig.z + (t1 * u.z);
    
    return true;
}

//set standard color of point
//orig = origin of ray that inter. at xi,yi,zi
v3d Sphere::colorP(v3d orig) {
    
    //amb, dif, spe
    v3d c1;
    c1.x = 0; c1.y = 0; c1.z = 0;
    vector<light*> l = *(getLight());
    if (l.size()<=0) return c1;
    float dotNL, dotSR;
    v3d Nu = normalize(makev3d(x,y,z, xi,yi,zi));
    v3d Su = normalize(makev3d(xi,yi,zi,  orig.x,orig.y,orig.z));
    cur = true; 
    for (int j=0; j<l.size(); j++) {
        c1.x += ambr*(l[j]->i.x);
        c1.y += ambg*(l[j]->i.y);
        c1.z += ambb*(l[j]->i.z);
        v3d Lu = normalize(scalMult(-1, l[j]->dir));
        if (arbInt(makev3d(xi,yi,zi), Lu)) {
            //c.x = 0; c.y = 0; c.z = 1;
            continue;
        }
        v3d Ru = calcRu(Nu, Lu);
        dotNL = dot(Nu,Lu);
        if (dotNL<0) dotNL=0;
        dotSR = dot(Su,Ru);
        if (dotSR<0) dotSR=0;
        c1.x +=   (l[j]->i.x)*((difr*dotNL) + (sper*pow(dotSR, n)));
        c1.y +=   (l[j]->i.y)*((difg*dotNL) + (speg*pow(dotSR, n)));
        c1.z +=   (l[j]->i.z)*((difb*dotNL) + (speb*pow(dotSR, n)));
    }
    
    
    //reflected
    v3d c2;
    v3d Ru = calcRu(Nu, Su);
    c2 = colArbRay(makev3d(xi,yi,zi), Ru);
    
    //refracted
    v3d c3;
    Ru = refr(Su,Nu, 1, 1.52);
    intInter(makev3d(xi,yi,zi), Ru);  //xi,yi,zi will be set to new intersection
    Nu = normalize(makev3d(xi,yi,zi, x,y,z));
    Ru = refr(scalMult(-1,Ru), Nu, 1,1.52);
    c3 = colArbRay(makev3d(xi,yi,zi), Ru);
    
    cur = false;
    
    //combine
    v3d c;
    c.x = (cSta*c1.x) + (cRefl*c2.x) + (cRefr*c3.x); 
    c.y = (cSta*c1.y) + (cRefl*c2.y) + (cRefr*c3.y);  
    c.z = (cSta*c1.z) + (cRefl*c2.z) + (cRefr*c3.z); 
    
    return c;
}



