#ifndef SPHERE_H_
#define SPHERE_H_

#include "v3d.h"

class Sphere {
public:
       Sphere(char * name, 
               float r, float x, float y, float z, 
               float ambr, float ambg, float ambb, 
               float difr, float difg, float difb, 
               float sper, float speg, float speb, int N,
               float cSta, float cRefl, float cRefr);
        float getr();
        float getDist();
        char* getName();
        bool intersects(v3d v);
        bool arbIntersects(v3d orig, v3d v);
        bool calcArbIntersects(v3d orig, v3d v);
        bool intInter(v3d orig, v3d v);
        float getArbDist(v3d a); //arb dist from xi,yi,zi to a
        v3d colorP(v3d orig); //colors xi, yi, zi
       
       
private:
        char * name;
        float r;
        float x, y, z;
        float ambr, ambg, ambb;
        float difr, difg, difb;
        float sper, speg, speb;
        float cSta, cRefl, cRefr;
        int n;
        float xi, yi, zi;
        float dist;
        bool cur;
};





#endif /*SPHERE_H_*/
