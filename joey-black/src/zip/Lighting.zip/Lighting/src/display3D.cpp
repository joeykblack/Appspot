#ifdef _WIN32
#define WIN32_EXTRALEAN   
#include <windows.h>
#endif

#include "display3D.h"
#include "Object.h"
#include <GL/glut.h>
#include <GL/GL.h>
#include <GL/glu.h>
#include <algorithm>
#include <string.h>
#include <iostream>
#include <math.h>
 

int sxa = -250; //left
int sya = 500; //up
int sxb = 500; //right
int syb = -250;  //down

vector<Object*> objects; 
vector<visSurf*> visS;
vector<light*> l;
Object* curob;
int win2=0;

int mo;
int menuo=2;



void draw3d() {
	glClearColor(1,1,1,1);
	glClear(GL_COLOR_BUFFER_BIT);	
	
	glColor3f(0,0,0);
	
	visS.clear();
	for (unsigned int i=0; i<objects.size(); i++) {
		objects[i]->draw();  //3DS will add visible surface to vis
	}
	//draw vis
	sortvis();
	//cout << endl;
	//cout << "Vis Surf zmax: " << endl;
	for (int i=0; i<visS.size(); i++) {
        visS[i]->o->draws(visS[i]->i);
        //cout << visS[i]->zmax << endl;
    }
	
	glutSwapBuffers();
}

void addvis(Object * o, int i, float zmax) {
     visSurf *v = new visSurf;
     v->o = o;
     v->i = i;
     v->zmax = zmax;
     visS.push_back(v);
}

void sortvis() {
     visSurf* temp;
     if (visS.size()==0) return;
     //cout << endl << "sort" << endl;
     //sort(visS.begin(), visS.end());
     for (int i=0; i<visS.size(); i++) {
     for (int j=i+1; j<visS.size(); j++) {
         //cout << "zmaxes: " << visS[i]->zmax << " " << visS[j]->zmax << endl;
         if (visS[i]->zmax > visS[j]->zmax) {
            temp = visS[i];
            visS[i] = visS[j];
            visS[j] = temp;
            //cout << visS[i]->zmax << endl;
         }
     }
     }
}


void creatDisplay() {
	glutInitWindowSize((int)(fabs(sxa)+fabs(sxb)), (int)(fabs(sya)+fabs(syb)));
	glutInitWindowPosition(470,10);
	win2 = glutCreateWindow("3D");
	glutDisplayFunc(draw3d);
	glutMouseFunc(mouse3d);
	
	glViewport(sxa,syb,sxb,sya);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D(sxa,sxb,syb,sya);
    glMatrixMode(GL_MODELVIEW);
	glDisable(GL_DEPTH_TEST);
	
	curob=new Object("p5t5.in");
	objects.push_back(curob);
	//curob=new Object("p2t5.in");
	//objects.push_back(curob);
	
	float i[3] = {.7,.7,.7};
	float pos[3] = {1000,1000,1000};
	float amb[3] = {.4,.4,.4};
    float dif[3] = {.6,.6,.6};
    float spe[3] = {.5,.5,.5};
	addLight(makeLight(i, pos, amb, dif, spe, 10));
	
	//menue
	mo = glutCreateMenu(menuFcnObj);
	if (curob!=NULL) glutAddMenuEntry(curob->getName(), 1);
	glutAttachMenu(GLUT_RIGHT_BUTTON);
}

void mouse3d(int button, int state, int x, int y) {
	if (state == GLUT_UP )
	{
		if ( button == 3 )
		{
			curob->setD(curob->getD()+10);
		}
		else if( button == 4 )
		{
			curob->setD(curob->getD()-10);
		}
	}
}

void load(char * file) {
    glutSetMenu(mo);
    curob=new Object(file);
	objects.push_back(curob);
	glutAddMenuEntry(curob->getName(), menuo);
	menuo++;
	glutSetWindow(getWindow());
	glutPostRedisplay();
}

Object * getCurO() {
	return curob;
}

int getWindow() {
	return win2;
}

void resize(int xa, int ya, int xb, int yb) {
	glutSetWindow(win2);
	glutReshapeWindow((int)(fabs(xa)+fabs(xb)), (int)(fabs(ya)+fabs(yb)));
	
	
	glViewport(xa,yb,xb,ya);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D(xa,xb,yb,ya);
    glMatrixMode(GL_MODELVIEW);
    
    
    glutPostRedisplay();
}

void clearS() {
	objects.clear();
	curob=NULL;
	glutSetMenu(mo);
	for (int i=1; i<menuo; i++) {
        glutRemoveMenuItem(1);
    }
    menuo=1;
	glutSetWindow(win2);
	glutPostRedisplay();
}

light* makeLight(float i[3], float pos[3], float amb[3], float dif[3], float spe[3], int n) {
    light* l1 = new light;
    l1->i[0] = i[0]; l1->i[1] = i[1]; l1->i[2] = i[2]; 
	l1->pos[0] = pos[0]; l1-> pos[1] = pos[1]; l1->pos[2] = pos[2];
	l1->amb[0] = amb[0]; l1->amb[1] = amb[1]; l1->amb[2] = amb[2]; 
	l1->dif[0] = dif[0]; l1->dif[1] = dif[1]; l1->dif[2] = dif[2]; 
	l1->spe[0] = spe[0]; l1->spe[1] = spe[1]; l1->spe[2] = spe[2]; 
	l1->n = n;
	return l1;
}

vector<light*>* getLight() {
    return &l;
}

void addLight(light* l1) {
     l.push_back(l1);
}

void redisplayD3D() {
     glutSetWindow(win2);
     glutPostRedisplay();
}


void menuFcnObj(int i) { 
     i--;
     //cout << "i: " << i << endl;
     if (i<objects.size() && i>=0) {
        curob = objects[i];
     }
     else {
          //cout << "out of bounds: " << i << endl;
     }
}

void turnOffLight() {
     l.clear();
}
