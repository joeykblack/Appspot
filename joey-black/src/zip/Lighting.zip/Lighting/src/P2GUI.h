#ifndef P2GUI_H_
#define P2GUI_H_

void createGUI(int argc, char** argv, char * name);
void print(char* s, float x, float y);
void textBox(int row, int col, float startx, char * text);
bool inTBox(int mx, int my, int row, int col, float startx, char * text);
void button(int row, int col, float startx, char * text);
bool inBBox(int mx, int my, int row, int col, float startx);
void updateScreen();
void loadFile();
void show();
void translate();
void scale();
void rotx();
void roty();
void rotz();
void rotab();
void zshx();
void zshy();
void xshy();
void xshz();
void yshx();
void yshz();
void clear();
void printCurO();
void togleSolid();

static int win1=0;

#endif /*P2GUI_H_*/
