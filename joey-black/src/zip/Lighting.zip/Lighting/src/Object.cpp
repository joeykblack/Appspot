#ifdef _WIN32
#define WIN32_EXTRALEAN   
#include <windows.h>
#endif

#include "Object.h"
#include "display3D.h"
#include "v3d.h"
#include <iostream>
#include <fstream>
#include <string.h>
#include <iomanip>
#include <math.h>
#include <GL/glut.h>
using namespace std;

static float d=1000;
 
//creates a new object given a file name
Object::Object(char name[]) {
	ifstream ins;
	ins.open (name);
	if (ins.is_open()) {
		ins >> filetype;
		if (strcmp("3DS", filetype)==0) wire = false;
		else wire = true;
		ins >> oname;
		ins >> np;
		points = new Point[np];
		for (int i=0; i<np; i++) {
			ins >> points[i].x;
			ins >> points[i].y;
			if ((strcmp("3DW", filetype)==0) || (strcmp("3DS", filetype)==0)) {
				ins >> points[i].z;
			}
			else {
				points[i].z = 0;
			}
		}
		ins >> ne;
		edges = new Edge[ne];
		for (int i=0; i<ne; i++) {
			ins >> edges[i].a;
			ins >> edges[i].b;
			if (strcmp("3DS", filetype)==0) {  //3DS points are labeled 1-n but need to be 0-(n-1)
               edges[i].a--;
               edges[i].b--;
            }
		}
		if (strcmp("3DS", filetype)==0) {
    		ins >> ns;
    		ins >> ncol;
    		//cout << "load ncol: " << ncol << endl;
    		surfaces = new Surface[ns];
    		for (int i=0; i<ns; i++) {
                surfaces[i].p = new int[ncol];
                for (int j=0; j<ncol; j++) {
                    ins >> surfaces[i].p[j];
                    surfaces[i].p[j]--; //3DS points are labeled 1-n but need to be 0-(n-1)
                }
            }
        }
	}
	else {
         cout << "Fail to open: " << name << endl;
    }
	
	ins.close();
	//print();
}


void Object::draw() {
    if (strcmp("3DS", filetype)==0) {
        for (int i=0; i<ns; i++) {
            v3d v1 = makev3d(points[surfaces[i].p[0]].x, points[surfaces[i].p[0]].y, points[surfaces[i].p[0]].z,
                points[surfaces[i].p[1]].x, points[surfaces[i].p[1]].y, points[surfaces[i].p[1]].z);
            v3d v2 = makev3d(points[surfaces[i].p[0]].x, points[surfaces[i].p[0]].y, points[surfaces[i].p[0]].z,
                points[surfaces[i].p[2]].x, points[surfaces[i].p[2]].y, points[surfaces[i].p[2]].z);
            v3d n = cros(v1, v2);
            v3d s = makev3d(points[surfaces[i].p[0]].x, points[surfaces[i].p[0]].y, points[surfaces[i].p[0]].z,  0,0,d);
            if (vis(n, s)) {
               addvis(this, i, findZmax(surfaces[i]));
               //cout << i << " vis: " << n.x << ", " << n.y << ", " << n.z << endl;
            }
            /*else {
                 cout << i << " not vis: " << n.x << ", " << n.y << ", " << n.z << endl;
                 cout << "  : " << v1.x << ", " << v1.y << ", " << v1.z << endl;
                 cout << "  : " << v2.x << ", " << v2.y << ", " << v2.z << endl;
            }*/
        }
    }
    else { 
    	glBegin(GL_LINES);
    		for (int e=0; e<ne; e++) {
                p3f(points[edges[e].a].x, points[edges[e].a].y, points[edges[e].a].z);
    			p3f(points[edges[e].b].x, points[edges[e].b].y, points[edges[e].b].z);
    		}
    	glEnd();
    }
}

//project 3d point
void Object::p3f(float x, float y, float z) {
	float zd = 1 - (z/d);
	glVertex2f(x/zd, y/zd);
}


void Object::draws(int i) {
     v3d v1 = makev3d(points[surfaces[i].p[0]].x, points[surfaces[i].p[0]].y, points[surfaces[i].p[0]].z,
                points[surfaces[i].p[1]].x, points[surfaces[i].p[1]].y, points[surfaces[i].p[1]].z);
     v3d v2 = makev3d(points[surfaces[i].p[0]].x, points[surfaces[i].p[0]].y, points[surfaces[i].p[0]].z,
                points[surfaces[i].p[2]].x, points[surfaces[i].p[2]].y, points[surfaces[i].p[2]].z);
     v3d Nu = cros(v1, v2);
     v3d Lu;
     v3d Su = makev3d(points[surfaces[i].p[0]].x, points[surfaces[i].p[0]].y, points[surfaces[i].p[0]].z,  0,0,d);
     v3d Ru;
     l = getLight();
     float r=0,g=0,b=0;
     //cout << endl;
     //cout << i << endl;
     float dotNL, dotSR;
     for (int li=0; li<(*l).size(); li++) {
         Lu = makev3d(points[surfaces[i].p[0]].x, points[surfaces[i].p[0]].y, points[surfaces[i].p[0]].z, 
              (*l)[li]->pos[0], (*l)[li]->pos[1], (*l)[li]->pos[2]);
         Ru = calcRu(Nu, Lu);
         dotNL = dot(Nu,Lu);
         if (dotNL<0) dotNL=0;
         dotSR = dot(Su,Ru);
         if (dotSR<0) dotSR=0;
         r += (*l)[li]->i[0] *  (  ((*l)[li]->amb[0]) + (((*l)[li]->dif[0])*(dotNL)) + (((*l)[li]->spe[0])*pow(dotSR,(*l)[li]->n))  )  ;
         g += (*l)[li]->i[1] *  (  ((*l)[li]->amb[1]) + (((*l)[li]->dif[1])*(dotNL)) + (((*l)[li]->spe[1])*pow(dotSR,(*l)[li]->n))  )  ;
         b += (*l)[li]->i[2] *  (  ((*l)[li]->amb[2]) + (((*l)[li]->dif[2])*(dotNL)) + (((*l)[li]->spe[2])*pow(dotSR,(*l)[li]->n))  )  ;
         //cout << " " << r << " " << g << " " << b << " " << dotNL << " " << dotSR << endl;
     }
     if (r>1) r=1;
     if (g>1) g=1;
     if (b>1) b=1;
     glColor3f(r, g, b);
     //cout << endl;
     //cout << "points " << i << endl;
     if (wire || wirem) glBegin(GL_LINE_LOOP);
     else glBegin(GL_POLYGON);
         for (int c=0; c<ncol; c++) {
             //cout << "p[c]: " << surfaces[i].p[c] << endl;
             if (surfaces[i].p[c]>=0) {
                   p3f(points[surfaces[i].p[c]].x, points[surfaces[i].p[c]].y, points[surfaces[i].p[c]].z); 
             }
         }
    glEnd();
} 


float Object::findZmax(Surface s) {
     float zmax = points[s.p[0]].z;
     //cout << endl << "Find zmax: " << endl;
     //cout << "ncol: " << ncol << endl;
     
     //cout << zmax << endl;
     for (int i=1; i<ncol; i++) {
         if (s.p[i]<0) continue;
         //cout << points[s.p[i]].z << endl;
         if (points[s.p[i]].z > zmax) zmax = points[s.p[i]].z;
     }
     //cout << "result: " << zmax << endl;
     return zmax;
}



char * Object::getName() {
	return oname;
}

void Object::print() {
	cout << endl << oname << endl;
	cout << "Num points: " << np << endl;
	for (int i=0; i<np; i++) {
		cout << points[i].x << " " << points[i].y << " " << points[i].z << endl;
	}
	cout << "Num edges: " << ne << endl;
	for (int i=0; i<ne; i++) {
		cout << edges[i].a << " " << edges[i].b << endl;
	}
	cout << endl;
}

void Object::setD(float newd) {
	d = newd;
	glutSetWindow(getWindow());
	glutPostRedisplay();
}

float Object::getD() {
	return d;
}



void Object::translate(float tx, float ty, float tz) {
	for (int i=0; i<np; i++) {
		points[i].x += tx;
		points[i].y += ty;
		points[i].z += tz;
	}
	glutSetWindow(getWindow());
	glutPostRedisplay();
}


void Object::scale(float sx, float sy, float sz, float fx, float fy, float fz) {
	translate(-fx, -fy, -fz);
	for (int i=0; i<np; i++) {
		points[i].x *= sx;
		points[i].y *= sy;
		points[i].z *= sz;
	}
	translate(fx, fy, fz);
}

void Object::rotx(float th, float yc, float zc) {
	float s = sin((th*M_PI)/180);
	float c = cos((th*M_PI)/180);
	float y,z;
	translate(0, -yc, -zc);
	for (int i=0; i<np; i++) {
		y = points[i].y;
		z = points[i].z;
		points[i].y = (y*c) - (z*s);
		points[i].z = (y*s) + (z*c);
	}
	translate(0, yc, zc);
}

void Object::roty(float th, float xc, float zc){
	float s = sin((th*M_PI)/180);
	float c = cos((th*M_PI)/180);
	float x,z;
	translate(-xc, 0, -zc);
	for (int i=0; i<np; i++) {
		x = points[i].x;
		z = points[i].z;
		points[i].x = (z*s) + (x*c);
		points[i].z = (z*c) - (x*s);
	}
	translate(xc, 0, zc);
}

void Object::rotz(float th, float xc, float yc){
	float s = sin((th*M_PI)/180);
	float c = cos((th*M_PI)/180);
	float x,y;
	translate(-xc, -yc, 0);
	for (int i=0; i<np; i++) {
		x = points[i].x;
		y = points[i].y;
		points[i].x = (x*c) - (y*s);
		points[i].y = (x*s) + (y*c);
	}
	translate(xc, yc, 0);
}


void Object::rotab(float th, float xb, float yb, float zb, float xa, float ya, float za) {
	translate(-xb, -yb, -zb);
	float th1;
	if ((xa-xb)==0) th1=-90;
	else th1=-atan( ((ya-yb)/(xa-xb)) ) *180/M_PI;
	float s = sin((th1*M_PI)/180);
	float c = cos((th1*M_PI)/180);
	float xa2 = (xa*c) - (ya*s);
	float xb2 = (xb*c) - (yb*s);
	float th2;
	if ((za-zb)==0) th2=-90; 
	else th2=-atan( ((xa2-xb2)/(za-zb)) ) *180/M_PI;
	//cout << "rotab" << endl;
	//cout << "th1: " << th1 << endl;
	//cout << "th2: " << th2 << endl;
	rotz(th1,0,0);
	roty(th2,0,0);
	rotz(th,0,0);
	roty(-th2,0,0);
	rotz(-th1,0,0);
	translate(xb, yb, zb);
}


void Object::zshx(float m) {
	float x;
	for (int i=0; i<np; i++) {
		x = points[i].x;
		points[i].x = x + (points[i].y/m);
	}
	glutSetWindow(getWindow());
	glutPostRedisplay();
}


void Object::zshy(float m){
	float y;
	for (int i=0; i<np; i++) {
		y = points[i].y;
		points[i].y = y + (points[i].x/m);
	}
	glutSetWindow(getWindow());
	glutPostRedisplay();
}

void Object::xshy(float m){
	float y;
	for (int i=0; i<np; i++) {
		y = points[i].y;
		points[i].y = y + (points[i].z/m);
	}
	glutSetWindow(getWindow());
	glutPostRedisplay();
}

void Object::xshz(float m){
	float z;
	for (int i=0; i<np; i++) {
		z = points[i].z;
		points[i].z = z + (points[i].y/m);
	}
	glutSetWindow(getWindow());
	glutPostRedisplay();
}

void Object::yshx(float m){
	float x;
	for (int i=0; i<np; i++) {
		x = points[i].x;
		points[i].x = x + (points[i].z/m);
	}
	glutSetWindow(getWindow());
	glutPostRedisplay();
}


void Object::yshz(float m){
	float z;
	for (int i=0; i<np; i++) {
		z = points[i].z;
		points[i].z = z + (points[i].x/m);
	}
	glutSetWindow(getWindow());
	glutPostRedisplay();
}

void togleSolid() {
     if (wirem) wirem=false;
     else wirem=true;
     //cout << wirem << endl;
     glutSetWindow(getWindow());
	 glutPostRedisplay();
}





