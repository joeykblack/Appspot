#ifdef _WIN32
#define WIN32_EXTRALEAN     // Only include the basics
#include <windows.h>
#endif

#include "P2GUI.h"
#include "lightGUI.h"
#include "display3D.h"
#include <GL/glut.h>
#include <GL/GL.h>

#include "v3d.h"
#include <iostream>
using namespace std;

// Initialize GLUT and start main loop
int main(int argc, char** argv) {
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB);
	createGUI(argc, argv, "3DS");
	creatDisplay();
	createLgui(); //light is created in creatDisplay()
	//start
	glutMainLoop();
}








