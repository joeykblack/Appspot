#ifndef DISPLAY3D_H_
#define DISPLAY3D_H_

#include "Object.h"
#include "v3d.h"
#include <vector>
#include <stdlib.h>
using namespace std;

struct visSurf {
       Object * o;
       int i;
       float zmax;
       bool operator < (const visSurf & v2) const {
            return zmax < v2.zmax;
       }
} ;




void creatDisplay();
void draw3d();
void mouse3d(int button, int state, int x, int y);
Object * getCurO();
int getWindow();
void resize(int xa, int ya, int xb, int yb);
void load(char * file);
void clearS();
void addvis(Object * o, int i, float zmax);
void sortvis();
light* makeLight(float i[3], float pos[3], float amb[3], float dif[3], float spe[3], int n);
vector<light*>* getLight();
void addLight(light* l1);
void redisplayD3D();
void menuFcnObj(int i);
void turnOffLight();


#endif /*DISPLAY3D_H_*/
