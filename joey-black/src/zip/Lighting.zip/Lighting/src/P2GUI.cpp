#ifdef _WIN32
#define WIN32_EXTRALEAN 
#include <windows.h>
#endif

#include <GL/glut.h>
#include <GL/GL.h>
#include <GL/glu.h>
#include <iostream>
#include <stdlib.h>
#include <string.h>
#include "P2GUI.h"
#include "Object.h"
#include "display3D.h"
using namespace std;

#define window_width  400
#define window_height 700

int textx=10, texty=700;

//text areas
char * cur;//[10] = "test";  //pointer to currently sellected text area
char screenXa[10]="-250", screenYa[10]="500";
int sXa, sYa;
char screenXb[10]="500", screenYb[10]="-250";
int sXb, sYb;
char sD[10]="1000";
float d;
char file[10] = "";
//Objects ?
char showS[5]="yes";
char transX[10]="", transY[10]="", transZ[10]="";
float tx, ty, tz;
char scaleX[10]="", scaleY[10]="", scaleZ[10]="";
char fixX[10]="", fixY[10]="", fixZ[10]="";
float sx, sy, sz;
float fx, fy, fz;
char rotxTh[10]="10", rotxYc[10]="", rotxZc[10]="";
float rxth, rxyc, rxzc;
char rotyTh[10]="10", rotyXc[10]="", rotyZc[10]="";
float ryth, ryxc, ryzc;
char rotzTh[10]="10", rotzXc[10]="", rotzYc[10]="";
float rzth, rzxc, rzyc;
char rotabTh[10]="30";
char rotabXb[10]="0", rotabYb[10]="0", rotabZb[10]="0";
char rotabXa[10]="100", rotabYa[10]="100", rotabZa[10]="100";
float rabth;
float rabxb, rabyb, rabzb;
float rabxa, rabya, rabza;
char shM[10]="";
float sm;
//current box
int curbr=1, curbc=10;
float curbx=40;

Object* curo;



//display window
void draw() {
	glClearColor(1,1,1,1);
	glClear(GL_COLOR_BUFFER_BIT);	
	
	glColor3f(0,0,0);
	
	//Screen:
	print("Screen:", 5, 20);
	print("Xa:", 15, 40); textBox(1, 10, 40, screenXa);
	print("Ya:", 150, 40); textBox(1, 10, 180, screenYa);
	print("Xb:", 15, 60); textBox(2, 10, 40, screenXb);
	print("Yb:", 150, 60); textBox(2, 10, 180, screenYb);
	button(3, 6, 15, "Update"); print("D:", 150, 80); textBox(3, 10, 180, sD);
	print("File:", 5, 120); textBox(5, 10, 60, file); button(5, 4, 180, "Load");
	//print("Objects:", 5, 140);
	//print("List of objects", 15, 220);
	//print("Show Selected:", 15, 240); button(11, 3, 160, showS); 
    button(9, 15, 200, "Print Selected");
    button(10, 12, 200, "Solid on/off");
	button(12, 9, 5, "Translate"); print("tx", 100, 260); textBox(12, 10, 120, transX);
		print("ty", 230, 260); textBox(12, 10, 250, transY);
		print("tz", 100, 280); textBox(13, 10, 120, transZ);
	button(14, 5, 5, "Scale"); 
		print("sx", 100, 300); textBox(14, 10, 120, scaleX);
		print("sy", 230, 300); textBox(14, 10, 250, scaleY);
		print("sz", 100, 320); textBox(15, 10, 120, scaleZ);
		print("fx", 100, 340); textBox(16, 10, 120, fixX); 
		print("fy", 230, 340); textBox(16, 10, 250, fixY);
		print("fz", 100, 360); textBox(17, 10, 120, fixZ);
	button(18, 7, 5, "RotateX"); 
		print("Yc", 100, 380); textBox(18, 10, 120, rotxYc);
		print("Zc", 230, 380); textBox(18, 10, 250, rotxZc);
		print("th", 100, 400); textBox(19, 10, 120, rotxTh);
	button(20, 7, 5, "RotateY"); 
		print("Xc", 100, 420); textBox(20, 10, 120, rotyXc);
		print("Zc", 230, 420); textBox(20, 10, 250, rotyZc);
		print("th", 100, 440); textBox(21, 10, 120, rotyTh);
	button(22, 7, 5, "RotateZ"); 
		print("Xc", 100, 460); textBox(22, 10, 120, rotzXc);
		print("Yc", 230, 460); textBox(22, 10, 250, rotzYc);
		print("th", 100, 480); textBox(23, 10, 120, rotzTh);
	button(24, 8, 5, "RotateAB"); 
		print("th", 100, 500); textBox(24, 10, 120, rotabTh);
		print("Xb", 100, 520); textBox(25, 10, 120, rotabXb);
		print("Yb", 230, 520); textBox(25, 10, 250, rotabYb);
		print("Zb", 100, 540); textBox(26, 10, 120, rotabZb);
		print("Xa", 100, 560); textBox(27, 10, 120, rotabXa); 
		print("Ya", 230, 560); textBox(27, 10, 250, rotabYa);
		print("Za", 100, 580); textBox(28, 10, 120, rotabZa);
	button(29, 4, 5, "zShx");
	button(29, 4, 55, "zShy");
	button(29, 4, 105, "xShy");
	button(29, 4, 155, "xShz");
	button(29, 4, 205, "yShx");
	button(29, 4, 255, "yShz");
	print("M", 5, 620); textBox(30, 10, 15, shM);
	button(32, 5, 5, "Clear");
	
	
	
	glColor3f(0.9,0.9,0);
	textBox(curbr, curbc, curbx, NULL); //draw cur box
	glutSwapBuffers();
}


//mouse listener
void mouse(int button, int state, int x, int y) {
	if (state == GLUT_DOWN) {
		//printf("Mouse x: %d, y: %d\n", x, y);
		if (inTBox(x, y, 1, 10, 40, screenXa)) {}
		else if (inTBox(x, y, 1, 10, 180, screenYa)) {}
		else if (inTBox(x, y, 2, 10, 40, screenXb)) {}
		else if (inTBox(x, y, 2, 10, 180, screenYb)) {}
		else if (inBBox(x, y, 3, 6, 15)) {updateScreen();}
		else if (inTBox(x, y, 3, 10, 180, sD)) {}
		else if (inTBox(x, y, 5, 10, 60, file)) {}
		else if (inBBox(x, y, 5, 4, 180)) {loadFile();}
		else if (inBBox(x, y, 11, 3, 160)) {show();}
		else if (inBBox(x, y, 9, 15, 200)) {printCurO();}
		else if (inBBox(x, y, 10, 12, 200)) {togleSolid();}
		else if (inBBox(x, y, 12, 9, 5)) {translate();}
		else if (inTBox(x, y, 12, 10, 120, transX)) {}
		else if (inTBox(x, y, 12, 10, 250, transY)) {}
		else if (inTBox(x, y, 13, 10, 120, transZ)) {}
		else if (inBBox(x, y, 14, 5, 5)) {scale();}
		else if (inTBox(x, y, 14, 10, 120, scaleX)) {}
		else if (inTBox(x, y, 14, 10, 250, scaleY)) {}
		else if (inTBox(x, y, 15, 10, 120, scaleZ)) {}
		else if (inTBox(x, y, 16, 10, 120, fixX)) {}
		else if (inTBox(x, y, 16, 10, 250, fixY)) {}
		else if (inTBox(x, y, 17, 10, 120, fixZ)) {}
		else if (inBBox(x, y, 18, 7, 5)) {rotx();}
		else if (inTBox(x, y, 18, 10, 120, rotxYc)) {}
		else if (inTBox(x, y, 18, 10, 250, rotxZc)) {}
		else if (inTBox(x, y, 19, 10, 120, rotxTh)) {}
		else if (inBBox(x, y, 20, 7, 5)) {roty();}
		else if (inTBox(x, y, 20, 10, 120, rotyXc)) {}
		else if (inTBox(x, y, 20, 10, 250, rotyZc)) {}
		else if (inTBox(x, y, 21, 10, 120, rotyTh)) {}
		else if (inBBox(x, y, 22, 7, 5)) {rotz();}
		else if (inTBox(x, y, 22, 10, 120, rotzXc)) {}
		else if (inTBox(x, y, 22, 10, 250, rotzYc)) {}
		else if (inTBox(x, y, 23, 10, 120, rotzTh)) {}
		else if (inBBox(x, y, 24, 7, 5)) {rotab();}
		else if (inTBox(x, y, 24, 10, 120, rotabTh)) {}
		else if (inTBox(x, y, 25, 10, 120, rotabXb)) {}
		else if (inTBox(x, y, 25, 10, 250, rotabYb)) {}
		else if (inTBox(x, y, 26, 10, 120, rotabZb)) {}
		else if (inTBox(x, y, 27, 10, 120, rotabXa)) {}
		else if (inTBox(x, y, 27, 10, 250, rotabYa)) {}
		else if (inTBox(x, y, 28, 10, 120, rotabZa)) {}
		else if (inBBox(x, y, 29, 5, 5)) {zshx();}
		else if (inBBox(x, y, 29, 5, 55)) {zshy();}
		else if (inBBox(x, y, 29, 5, 105)) {xshy();}
		else if (inBBox(x, y, 29, 5, 155)) {xshz();}
		else if (inBBox(x, y, 29, 5, 205)) {yshx();}
		else if (inBBox(x, y, 29, 5, 255)) {yshz();}
		else if (inTBox(x, y, 30, 10, 15, shM)) {}
		else if (inBBox(x, y, 32, 5, 5)) {clear();}
	}
	
	glutPostRedisplay();
}



//type in sellected area
void keypress (unsigned char key, int x, int y) {
	//display
	glutPostRedisplay();
	
	//backspace
	if (key==8) {
		cur[strlen(cur) - (cur[0] != '\0')] = '\0';
		return;
	}
	
	//add to string
	if ( strlen(cur)<9 && (((key>=48 && key<=57) || key==46 || key==45) || cur==file) ) {
		strncat(cur, (char*)(&key), 1);
	}
}




// Initialze OpenGL perspective matrix
void GL_Setup(int width, int height)
{
	glOrtho(0,width,height,0,0,1);
}

// Initialize GLUT and start main loop
void createGUI(int argc, char** argv, char * name) {
	cur = screenXa;
	
	glutInitWindowSize(window_width, window_height);
	glutInitWindowPosition(20,10);
	win1 = glutCreateWindow(name);
	//register functions
	glutDisplayFunc(draw);
	glutKeyboardFunc(keypress);
	glutMouseFunc(mouse);
	//set up view
	GL_Setup(window_width, window_height);
	
	
}



//Display functions
void print(char * s, float x, float y) {
	for (unsigned int i=0; i<strlen(s); i++) {  
	  glRasterPos2f(x, y);
	  glutBitmapCharacter(GLUT_BITMAP_9_BY_15, s[i]);
	  x += 9;
	}
}
 
//(row in window, number of col, starting x pos, text)
void textBox(int row, int col, float startx, char * text) {
	glBegin(GL_LINE_LOOP);
		glVertex2f(startx, row*20 + 23);
		glVertex2f(startx, row*20+5);
		glVertex2f(startx+(col*9)+5, row*20+5);
		glVertex2f(startx+(col*9)+5, row*20 + 23);
	glEnd();
	if (text!=NULL) print(text, startx+2, row*20+20);
}

void button(int row, int col, float startx, char * text) {
	glBegin(GL_LINE_LOOP);
		glVertex2f(startx, row*20 + 23);
		glVertex2f(startx, row*20+5);
		glVertex2f(startx+(col*9)+5, row*20+5);
		glVertex2f(startx+(col*9)+5, row*20 + 23);
	glEnd();
	if (text!=NULL) print(text, startx+2, row*20+20);
}

bool inTBox(int mx, int my, int row, int col, float startx, char * text) {
	if ( (mx>startx) && (mx<startx+(col*9)+5) && (my>row*20+5) && (my<row*20 + 23) ) {
		curbr=row;
		curbc=col;
		curbx=startx;
		cur = text;
		return true;
	}
	return false;
}

bool inBBox(int mx, int my, int row, int col, float startx) {
	if ( (mx>startx) && (mx<startx+(col*9)+5) && (my>row*20+5) && (my<row*20 + 23) ) {
		return true;
	}
	return false;
}

void updateScreen() {
	sXa = (int)strtod(screenXa, NULL);
	sYa = (int)strtod(screenYa, NULL);
	sXb = (int)strtod(screenXb, NULL);
	sYb = (int)strtod(screenYb, NULL);
	resize(sXa,sYa,sXb,sYb);
	d = strtod(sD, NULL);
	curo = getCurO();
	if (curo==NULL) return;
	curo->setD(d);
}

void loadFile() {
	load(file);
}

void show() {
	if (strcmp(showS, "yes")==0) {
		strcpy(showS, "no");
	}
	else {
		strcpy(showS, "yes");
	}
}

void printCurO() {
	curo = getCurO();
	if (curo==NULL) return;
	curo->print();
}
	
	

/*
 * Transformations	
*/
void translate() {
	curo = getCurO();
	if (curo==NULL) return;
	//cout << "name: " << curo->getName() << endl;
	//cout << "translate" << endl;
	tx=strtod(transX, NULL);
	ty=strtod(transY, NULL);
	tz=strtod(transZ, NULL);
	//cout << "tx: " << tx << " ty: " << ty << " tz: " << tz << endl;
	curo->translate(tx, ty, tz);
}

void scale() {
	curo = getCurO();
	if (curo==NULL) return;
	sx=strtod(scaleX, NULL);
	sy=strtod(scaleY, NULL);
	sz=strtod(scaleZ, NULL);
	fx=strtod(fixX, NULL);
	fy=strtod(fixY, NULL);
	fz=strtod(fixZ, NULL);
	curo->scale(sx,sy,sz,fx,fy,fz);
}

void rotx() {
	curo = getCurO();
	if (curo==NULL) return;
	rxth=strtod(rotxTh,NULL);
	rxyc=strtod(rotxYc,NULL);
	rxzc=strtod(rotxZc,NULL);
	curo->rotx(rxth,rxyc,rxzc);
}

void roty() {
	curo = getCurO();
	if (curo==NULL) return;
	ryth=strtod(rotyTh,NULL);
	ryxc=strtod(rotyXc,NULL);
	ryzc=strtod(rotyZc,NULL);
	curo->roty(ryth,ryxc,ryzc);
}

void rotz() {
	curo = getCurO();
	if (curo==NULL) return;
	rzth=strtod(rotzTh,NULL);
	rzxc=strtod(rotzXc,NULL);
	rzyc=strtod(rotzYc,NULL);
	curo->rotz(rzth,rzxc,rzyc);
}

void rotab() {
	curo = getCurO();
	if (curo==NULL) return;
	rabth=strtod(rotabTh,NULL);
	rabxb=strtod(rotabXb,NULL);
	rabyb=strtod(rotabYb,NULL);
	rabzb=strtod(rotabZb,NULL);
	rabxa=strtod(rotabXa,NULL);
	rabya=strtod(rotabYa,NULL);
	rabza=strtod(rotabZa,NULL);
	curo->rotab(rabth, rabxb, rabyb, rabzb, rabxa, rabya, rabza);
}

void zshx() {
	sm = strtod(shM, NULL);
	curo = getCurO();
	if (curo==NULL) return;
	curo->zshx(sm);
}

void zshy() {
	sm = strtod(shM, NULL);
	curo = getCurO();
	if (curo==NULL) return;
	curo->zshy(sm);
}

void xshy() {
	sm = strtod(shM, NULL);
	curo = getCurO();
	if (curo==NULL) return;
	curo->xshy(sm);
}

void xshz() {
	sm = strtod(shM, NULL);
	curo = getCurO();
	if (curo==NULL) return;
	curo->xshz(sm);
}

void yshx() {
	sm = strtod(shM, NULL);
	curo = getCurO();
	if (curo==NULL) return;
	curo->yshx(sm);
}

void yshz() {
	sm = strtod(shM, NULL);
	curo = getCurO();
	if (curo==NULL) return;
	curo->yshz(sm);
}

void clear() {
	clearS();
}






