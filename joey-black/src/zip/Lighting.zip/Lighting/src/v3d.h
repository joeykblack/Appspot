#ifndef V3D_H
#define V3D_H

struct v3d {
       float x;
       float y;
       float z;
} ;

float dot(v3d v1, v3d v2);
v3d cros(v3d v1, v3d v2);
v3d makev3d(float x1, float y1, float z1, float x2, float y2, float z2);
v3d makev3d(float x, float y, float z);
bool vis(v3d n, v3d s);
v3d calcRu(v3d Nu, v3d Lu);

#endif //V3D_H
