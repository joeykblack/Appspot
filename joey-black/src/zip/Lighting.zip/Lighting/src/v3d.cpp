#include "v3d.h"
#include <math.h>
#include <iostream>

using namespace std;

float dot(v3d v1, v3d v2) {
    float magv1 = sqrt(pow(v1.x,2) + pow(v1.y,2) + pow(v1.z,2)); 
    float magv2 = sqrt(pow(v2.x,2) + pow(v2.y,2) + pow(v2.z,2)); 
    return ((v1.x*v2.x) + (v1.y*v2.y) + (v1.z*v2.z)) / (magv1 * magv2);
}


v3d cros(v3d v1, v3d v2) {
    v3d v3;
    v3.x = (v1.y*v2.z) - (v1.z*v2.y);
    v3.y = (v1.z*v2.x) - (v1.x*v2.z);
    v3.z = (v1.x*v2.y) - (v1.y*v2.x);
    return v3;
}

v3d makev3d(float x1, float y1, float z1, float x2, float y2, float z2) {
    v3d v;
    v.x = x2 - x1;
    v.y = y2 - y1;
    v.z = z2 - z1;
    return v;
}

v3d makev3d(float x, float y, float z) {
    v3d v;
    v.x = x;
    v.y = y;
    v.z = z;
    return v;
}

bool vis(v3d n, v3d s) {
     return dot(n, s) > 0;
}

v3d calcRu(v3d Nu, v3d Lu) {
    v3d v;
    v.x = Nu.x; v.y = Nu.y; v.z = Nu.z; 
    float d = dot(Nu, Lu);
    v.x *= 2*d; v.y *= 2*d; v.z *= 2*d;
    v.x -= Lu.x; v.y -= Lu.y; v.z -= Lu.z;
    return v;
}





