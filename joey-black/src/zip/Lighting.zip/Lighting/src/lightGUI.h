#ifndef LIGHTGUI_H
#define LIGHTGUI_H

struct TBox {
       int row;
       int col;
       char * text;
};

struct Button {
       int row;
       int col;
       int numcol;
       char * text;
       void (*act)();
};

void createLgui();
void update();
void drawl();
void mousel(int button, int state, int x, int y) ;
void keypressl(unsigned char key, int x, int y);
void textBoxl(int row, int col, char * text);
void printl(char * s, int row, int col);
void buttonl(int row, int col, float numcol, char * text) ;
bool inTBoxl(int mx, int my, int row, int col, char * text);
bool inBBoxl(int mx, int my, int row, int col, int numcol);
TBox* makeTBox(int row, int col, char * text);
Button* makeButton(int row, int col, int numcol, char * text, void (*act)());
void update();
void menuFcn(int i);
void setLight(int i);
void clearL();


static int winl=0;

#endif //LIGHTGUI_H
