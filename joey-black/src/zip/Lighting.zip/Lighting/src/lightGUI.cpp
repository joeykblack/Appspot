
#ifdef _WIN32
#define WIN32_EXTRALEAN 
#include <windows.h>
#endif


#include <GL/glut.h>
#include <GL/GL.h>
#include <GL/glu.h>
#include <iostream>
#include <stdlib.h>
#include <string.h>
#include <vector>
#include <stdio.h>
#include "Object.h"
#include "display3D.h"
#include "lightGUI.h"
using namespace std;

#define window_width  400
#define window_height 300





vector<TBox*> tboxes;
vector<Button*> buttons;


//text areas
char posx[10]="", posy[10]="", posz[10]="";
int px, py, pz;
char inr[10]="", ing[10]="", inb[10]="";
int ir, ig, ib;
char ambr[10]="", ambg[10]="", ambb[10]="";
int ar, ag, ab;
char difr[10]="", difg[10]="", difb[10]="";
int dr, dg, db;
char sper[10]="", speg[10]="", speb[10]="";
int sr, sg, sb;
char N[10]="";
int n;

//current text
char * curl;
int curbrl, curbcl;

//current light source
light* li=NULL;

int menu=3; //number of next menu entry.  Number of light in array +2. Number of light in list +1
int ml;




// Initialize GLUT and start main loop
void createLgui() {
	curl = posx;
    curbrl=2, curbcl=2;
	
	//set up window
	glutInitWindowSize(window_width, window_height);
	glutInitWindowPosition(1000,20);
	winl = glutCreateWindow("Light");
	//register functions
	glutDisplayFunc(drawl);
	glutKeyboardFunc(keypressl);
	glutMouseFunc(mousel);
	//set up view
	gluOrtho2D(0,window_width,window_height,0);
	
	//initialize boxes
	setLight(0);
	
	//text boxes
	tboxes.push_back(makeTBox(2,2,posx));
	tboxes.push_back(makeTBox(2,15,posy));
	tboxes.push_back(makeTBox(2,28,posz));
	
	tboxes.push_back(makeTBox(4,2,inr));
	tboxes.push_back(makeTBox(4,15,ing));
	tboxes.push_back(makeTBox(4,28,inb));
	
	tboxes.push_back(makeTBox(6,2,ambr));
	tboxes.push_back(makeTBox(6,15,ambg));
	tboxes.push_back(makeTBox(6,28,ambb));
	
	tboxes.push_back(makeTBox(8,2,difr));
	tboxes.push_back(makeTBox(8,15,difg));
	tboxes.push_back(makeTBox(8,28,difb));
	
	tboxes.push_back(makeTBox(10,2,sper));
	tboxes.push_back(makeTBox(10,15,speg));
	tboxes.push_back(makeTBox(10,28,speb));
	tboxes.push_back(makeTBox(12,2,N));
	
	//buttons
	buttons.push_back(makeButton(14,1,6,"Update",update));
	buttons.push_back(makeButton(14, 8, 5, "Clear", clearL));
	
	//menue
	ml = glutCreateMenu(menuFcn);
	glutAddMenuEntry("Add new Light", 1);
	glutAddMenuEntry("Light1", 2);
	glutAttachMenu(GLUT_RIGHT_BUTTON);
}



/*
*  Listeners
*/

//type in sellected area
void keypressl (unsigned char key, int x, int y) {
	//display
	glutPostRedisplay();
	
	//backspace
	if (key==8) {
		curl[strlen(curl) - (curl[0] != '\0')] = '\0';
		return;
	}
	
	//add to string
	if ( strlen(curl)<9 && (((key>=48 && key<=57) || key==46 || key==45)) ) {
		strncat(curl, (char*)(&key), 1);
	}
}

//mouse listener
void mousel(int button, int state, int x, int y) {
	if (state == GLUT_DOWN) {
         for (int i=0; i<tboxes.size(); i++) {
             if (inTBoxl(x, y, tboxes[i]->row, tboxes[i]->col, tboxes[i]->text)) return;
         }
         for (int i=0; i<buttons.size(); i++) { 
             if (inBBoxl(x, y, buttons[i]->row, buttons[i]->col, buttons[i]->numcol)) {
                    buttons[i]->act();
             }
         }   
    }
    glutPostRedisplay();
}

//display window
void drawl() {
	glClearColor(1,1,1,1);
	glClear(GL_COLOR_BUFFER_BIT);	
	glColor3f(0,0,0);
	
	
	printl("Position:", 1, 0);
	printl("Intensity:", 3, 0);
	printl("Ambient:", 5,0);
	printl("Diffused:", 7, 0);
	printl("Specular:", 9, 0);
	printl("N:", 11, 0);
	//textBoxl(2,2,posx);
	for (int i=0; i<tboxes.size(); i++) {
        textBoxl(tboxes[i]->row, tboxes[i]->col, tboxes[i]->text);
    }
    for (int i=0; i<buttons.size(); i++) { 
        buttonl(buttons[i]->row, buttons[i]->col, buttons[i]->numcol, buttons[i]->text);
    }
	
	
	glColor3f(0.9,0.9,0);
	textBoxl(curbrl, curbcl, NULL); //draw cur box
	glutSwapBuffers();
}





/*
* Display functions
*/


void printl(char * s, int row, int col) {
    float x=col*9;
    float y=row*20;
	for (unsigned int i=0; i<strlen(s); i++) {  
	  glRasterPos2f(x, y);
	  glutBitmapCharacter(GLUT_BITMAP_9_BY_15, s[i]);
	  x += 9;
	}
}
 
//(row in window, number of col, starting x pos, text)
void textBoxl(int row, int col, char * text) {
    int numcol=10;
    row--;
    float startx = col*9;
	glBegin(GL_LINE_LOOP);
		glVertex2f(startx, row*20 + 23);
		glVertex2f(startx, row*20+5);
		glVertex2f(startx+(numcol*9)+5, row*20+5);
		glVertex2f(startx+(numcol*9)+5, row*20 + 23);
	glEnd();
	row++;
	if (text!=NULL) printl(text, row, col);
}

void buttonl(int row, int col, float numcol, char * text) {
    float startx = col*9;
    row--;
	glBegin(GL_LINE_LOOP);
		glVertex2f(startx, row*20 + 23);
		glVertex2f(startx, row*20+5);
		glVertex2f(startx+(numcol*9)+5, row*20+5);
		glVertex2f(startx+(numcol*9)+5, row*20 + 23);
	glEnd();
	row++;
	if (text!=NULL) printl(text, row, col);
}

bool inTBoxl(int mx, int my, int row, int col, char * text) {
    float startx = col*9;
    int numcol = 10;
    row--;
	if ( (mx>startx) && (mx<startx+(numcol*9)+5) && (my>row*20+5) && (my<row*20 + 23) ) {
		curbrl=++row;
		curbcl=col;
		curl = text;
		return true;
	}
	return false;
}

bool inBBoxl(int mx, int my, int row, int col, int numcol) {
    float startx = col*9;
    row--;
	if ( (mx>startx) && (mx<startx+(numcol*9)+5) && (my>row*20+5) && (my<row*20 + 23) ) {
		return true;
	}
	return false;
}



//constructors
TBox* makeTBox(int row, int col, char * text) {
      TBox* tb = new TBox;
      tb->row=row;
      tb->col=col;
      tb->text=text;
      return tb;
}


Button* makeButton(int row, int col, int numcol, char * text, void (*act)()) {
        Button * b = new Button;
        b->row=row;
        b->col=col;
        b->numcol=numcol;
        b->text=text;
        b->act=act;
        return b;
}


//button actions
void update() {
     if (li==NULL) return;
     li->pos[0] = strtod(posx, NULL);
     li->pos[1] = strtod(posy, NULL);
     li->pos[2] = strtod(posz, NULL);
     li->i[0] = strtod(inr, NULL);
     li->i[1] = strtod(ing, NULL);
     li->i[2] = strtod(inb, NULL);
     li->amb[0] = strtod(ambr, NULL);
     li->amb[1] = strtod(ambg, NULL);
     li->amb[2] = strtod(ambb, NULL);
     li->dif[0] = strtod(difr, NULL);
     li->dif[1] = strtod(difg, NULL);
     li->dif[2] = strtod(difb, NULL);
     li->spe[0] = strtod(sper, NULL);
     li->spe[1] = strtod(speg, NULL);
     li->spe[2] = strtod(speb, NULL);
     li->n = atoi(N);
     redisplayD3D();
}


void menuFcn(int i) {
     if (i==1) {
          char name[10] = "Light";
          sprintf (name, "%s%d", "Light", (menu-1));
          glutAddMenuEntry(name, menu);
          light* l1 = new light;
          l1->i[0] = 0; l1->i[1] = 0; l1->i[2] = 0; 
	      l1->pos[0] = 0; l1-> pos[1] = 0; l1->pos[2] = 0;
   	      l1->amb[0] = 0; l1->amb[1] = 0; l1->amb[2] = 0; 
	      l1->dif[0] = 0; l1->dif[1] = 0; l1->dif[2] = 0; 
	      l1->spe[0] = 0; l1->spe[1] = 0; l1->spe[2] = 0; 
	      l1->n = 0;
	      addLight(l1);
	      setLight(menu-2);
          menu++;   
     }
     else {
          setLight(i-2);
     }
     glutPostRedisplay();
}

void setLight(int i) {
     vector<light*>* lights = getLight();
     if ((*lights).size()<=0) {
        cout << "no light: " << (*lights).size() << endl;
        return;
     }
     li = (*lights)[i];
     sprintf(posx, "%.2f", li->pos[0]); 
     sprintf(posy, "%.2f", li->pos[1]); 
     sprintf(posz, "%.2f", li->pos[2]); 
     sprintf(inr, "%.2f", li->i[0]); 
     sprintf(ing, "%.2f", li->i[1]); 
     sprintf(inb, "%.2f", li->i[2]);
     sprintf(ambr, "%.2f", li->amb[0]);  
     sprintf(ambg, "%.2f", li->amb[1]); 
     sprintf(ambb, "%.2f", li->amb[2]);
     sprintf(difr, "%.2f", li->dif[0]);  
     sprintf(difg, "%.2f", li->dif[1]);
     sprintf(difb, "%.2f", li->dif[2]);
     sprintf(sper, "%.2f", li->spe[0]);
     sprintf(speg, "%.2f", li->spe[1]);
     sprintf(speb, "%.2f", li->spe[2]);
     sprintf(N, "%i", li->n);
}


void clearL() {
     glutSetMenu(ml);
	 for (int i=1; i<menu-1; i++) {
        glutRemoveMenuItem(2);
     }
     menu=2; 
     turnOffLight();
     li = NULL;
     sprintf(posx, "%.2f", 0); 
     sprintf(posy, "%.2f", 0); 
     sprintf(posz, "%.2f", 0); 
     sprintf(inr, "%.2f", 0); 
     sprintf(ing, "%.2f", 0); 
     sprintf(inb, "%.2f", 0);
     sprintf(ambr, "%.2f", 0);  
     sprintf(ambg, "%.2f", 0); 
     sprintf(ambb, "%.2f", 0);
     sprintf(difr, "%.2f", 0);  
     sprintf(difg, "%.2f", 0);
     sprintf(difb, "%.2f", 0);
     sprintf(sper, "%.2f", 0);
     sprintf(speg, "%.2f", 0);
     sprintf(speb, "%.2f", 0);
     sprintf(N, "%i", 0);
     redisplayD3D();
}




